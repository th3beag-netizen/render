# Beegi 26.3 migration assessment

## New source revision (NOT gameplay/build verified)

- Extracted a pure-Java rotation helper to explicitly face target positions in all directions. Used in both Auras and Spear Rush (unverified server effects).
- Replaced hardcoded east-only Block Flood exit with an unobstructed two-high straight corridor among east/west/south/north, falling back to floor-only placement when none is confirmed.
- Added regression tests for all four exit directions and 360-degree rotation.
- Verified `loom_version=1.19-SNAPSHOT` and Fabric API `0.166.2+26.3` are published; actual dependency downloads and compilation remain blocked in this environment.

## Completed source work (NOT gameplay/build verified)

- Added GitHub Actions Java 25 / Gradle 9.7.1 compile workflow (not executed here).
- Fixed module-preset conflicting selection counts.
- Fixed malformed configuration values interrupting load; atomic save writes.
- Fixed spear-prime phase incorrectly triggering stuck detection.
- Added offline tests covering these regressions.

- Updated invalid Fabric screen event imports to the `client.screen.v1` namespace.
- Expanded catalog from 4 to 15 source-driven modules (and added a World category).
- Replaced the short menu with a paged category view, including preset selection, restore and settings.
- Config retention: saved module states, selected preset modules, range and flood radius.
- Conflict rules: Rage Kill Aura vs Kill Aura; Spear Rush vs Target Orbit.
- Combat Guard on world join and one-click preset restore.
- A deterministic adaptive spear state controller and orbit obstacle/stuck recovery controller.
- 360-degree player target scanning, crosshair TriggerBot, standard forward-facing Kill Aura.
- Vanilla attack interaction, basic movement keys, hotbar-only Block Flood interaction attempts.
- Real landing-based No Fall attempt, not just slow-falling or fake local fall-distance resets.
- Tests: core catalog, preset/guard, range limits, anti-trap geometry, movement decisions, config persistence.
- Full inventory of 135 legacy module classes and Beegi-specific additions.

## Incomplete / not validated

- Compilation against Minecraft 26.3 (blocked by missing JDK25 and network access for Fabric Maven in this environment).
- In-game execution, network/server behavior, crash testing, GUI visuals and keybinds.
- Vanilla true Reach 100 and Timer 100× hooks, world-space Hit Circle, Crystal Rage/Anchor Rage and base Auras, visual/ESP/render mods, automation & building macros, other legacy modules.
- Spear Rush and Block Flood advanced terrain navigation/placement confirmation are heuristic implementations and not behaviorally equivalent to legacy modules.
- No Fall only attempts a legal water-bucket placement. It cannot guarantee protection.
- Client-side range selection is not a valid long-distance hit bypass. Client-side rapid charge is not a server cooldown bypass.

**Release decision:** NOT READY for a distributable binary. See `MODULE_INVENTORY.csv` for every legacy module's explicit status.
