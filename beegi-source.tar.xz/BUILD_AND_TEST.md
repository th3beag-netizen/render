# Reproducible build checklist

1. Install Minecraft Java 26.3 + Fabric Loader; install JDK 25 and Gradle 9.7.1 or compatible. See `BUILD_WITH_GITHUB_ACTIONS.md` to use CI instead of local tooling.
2. Run `./test-core.sh` to verify version-independent logic.
3. Run `gradle build` from this directory. Resolve compile errors against **actual 26.3** Mojang mappings (never by relabeling 1.21.11 classes).
4. Start a disposable 26.3 Fabric instance with `gradle runClient`. Test title-screen Right Shift, pagination, presets and config first.
5. Test each game module separately in a flat creative single-player world; check `latest.log` for exceptions.
6. Test world changes/disconnect, GUI focus, unloading targets, inventory slot changes and collisions.
7. Test any multiplayer behavior only with permission; failed hits and placement corrections are server authority, not proof of a working bypass.

## Missing dependencies in this build environment

`java -version` => OpenJDK 21, not JDK 25. `gradle` is not installed, `maven.fabricmc.net` DNS is unavailable. No valid `26.3` Fabric build or gameplay verification can be claimed.
