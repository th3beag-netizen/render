# Beegi 26.3 next-build changelog

**Status: source only. No verified 26.3 JAR.**

## Corrections made

1. Added `logic/AimMath.java`: yaw/pitch from eye-to-eye positions including targets behind the camera; used when Kill Aura / Rage Kill Aura and Spear Rush choose targets. Client facing can visibly rotate the view and does not override a multiplayer server's attack checks.
2. Hardened Block Flood's player safety: detects a clear two-block-high walkway spanning the configured flood radius in any of four directions (east, west, south, north); if none is clear, limits placements to floor-height positions. This is a heuristic, not full pathfinding.
3. Added `RuntimeSafetyLogicTest` and included it in the offline test script. Tests cover all 4 directions, floor-only fallback and cardinal/vertical rotation math.

## Build limitations

- Local environment has Java 21, no Gradle and cannot resolve/download external hosts. The true Fabric/Minecraft 26.3 compilation **was not run**.
- Source code cannot be placed in `.minecraft/mods`.
- GitHub Actions (`.github/workflows/build.yml`) can attempt compilation with Java 25 in an internet-enabled repository. A green build is still not the same as successful gameplay testing.
- The remainder of the legacy modules still need porting. The full list is in `MODULE_INVENTORY.csv`.
