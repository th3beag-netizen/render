# Beegi Client — Minecraft 26.3 (source revision, NOT a compiled mod)

**Status: PARTIAL SOURCE PORT. NOT a compiled or verified Minecraft 26.3 mod JAR.**

**This revision (21 November 2026):** Adds an explicit 360-degree target rotation calculation (used by combat attack paths and Spear Rush), four-way escape-corridor evaluation for hotbar-only Block Flood, and regression tests. These are logic improvements, not evidence of successful Minecraft compilation. See `CHANGELOG_NEXT_BUILD.md`.

**Prior revisions:** `.github/workflows/build.yml` can build with Java 25 and Gradle 9.7.1 on GitHub Actions; see `BUILD_WITH_GITHUB_ACTIONS.md`. Offline-tested fixes: malformed config recovery, atomic config saving, correct preset conflict counting, and Spear Rush wind-up no longer counted as a collision. This does not establish 26.3 runtime compatibility.

This is an expanded Fabric 26.3 developer project, based on the previous Beegi starter and the **user-provided Peegi 1.4.24** compiled mod. The original archive contains **135 legacy module class files** plus 14 Beegi-specific module classes and additional builder/easyplace modules. These are recorded in `MODULE_INVENTORY.csv` so nothing from the legacy feature list is silently omitted.

## Expanded 26.3 modules with source handlers (runtime unverified)

- Combat: Kill Aura (forward-facing), Rage Kill Aura (360-degree target scan), TriggerBot, Target Scan Range (3–100 blocks; **not vanilla multiplayer reach**), Rapid Charge (client-side cooldown), auto-lock Target Orbit, adaptive Spear Rush.
- Movement: Auto Sprint, Auto Walk, Auto Jump, Auto Sneak, No Fall (attempt water-bucket landing, **requires water in hotbar**; not invulnerability).
- World: Block Flood (hotbar building blocks only, no intentional cooldown, max 16 use-on-block interactions/tick, exit corridor preserved), Auto Eat (held food only).
- Client: Combat Guard (automatically disables Combat category on level join; manual one-click preset restores chosen modules), configurable saved preset.
- Paged menu for all source-backed modules, opened with Right Shift both on the title screen and in-game; settings and selected-module preset selection.

These are source reimplementations, not proven equivalent to the old versions; they do not bypass server controls. The **Spear Rush auto-controller has no manual tuning sliders**, as requested. Its physics and attack timing still need gameplay validation.

## IMPORTANT: Features still not ported

The remainder of the legacy client's 135 modules (many ESP/rendering features, builder/autopilot systems, macros, inventory systems, crystal and anchor explosion logic, vanilla reach patch, 100× Timer tick hook, ground Hit Circle, etc.) are **not implemented in this project**. The inventory gives every original class an explicit status. They are **not shown as fake working toggles**.

## Build

Requires JDK 25 and network access for Gradle/Minecraft/Fabric artifacts. The settings target Minecraft 26.3, Fabric Loader 0.20.1, Fabric Loom 1.19-SNAPSHOT and Fabric API 0.166.2+26.3 from the official example project.

```bash
# With JDK 25 and Gradle 9.6+ available
# In this folder:
gradle build
# Dev game:
gradle runClient
```

The development environment used to prepare this project has **Java 21 and no network access** to Fabric Maven, so I attempted but could not execute `gradle build` here. A GitHub Actions workflow is included for a real Java 25 build; it has not been run here. Therefore the 26.3 Minecraft-dependent source **has not been compiled against the actual game** and no playable JAR is provided. Expect API fixes when building. Do not drop this source ZIP into the mods folder.

Pure-Java module state, combat guard/preset, flood safety geometry, spear/orbit movement-planner tests can be run locally with JDK 21+ and Python 3:

```bash
./test-core.sh
```

## Compatibility and license

- Test in a private/disposable world; server hit reach, fall damage, inventory and tick authority remains server-side.
- Minecraft 26.3 uses Mojang-mapped symbols rather than the old Yarn references. Runtime features need independent 26.3 mapping/behavior verification.
- `LICENSE` contains GNU GPLv3 from the user-supplied Anubis/Peegi base. `MODULE_INVENTORY.csv` records the original class names and provenance. This source is an independent reimplementation from feature behavior, not a disassembled source dump.
- Fabric example and 26.3 docs: https://github.com/FabricMC/fabric-example-mod/tree/26.3 and https://docs.fabricmc.net/develop/porting/
