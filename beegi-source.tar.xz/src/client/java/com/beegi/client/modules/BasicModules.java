package com.beegi.client.modules;

import com.beegi.client.BeegiClient;
import com.beegi.client.core.ModuleCatalog;
import com.beegi.client.logic.FloodPlanner;
import com.beegi.client.logic.AimMath;
import com.beegi.client.logic.MovementPlanner;
import com.beegi.client.logic.MovementPlanner.V2;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.List;
import java.util.UUID;

/** Source port of simple modules; all actions use vanilla client pathways.
 *  Server validation remains authoritative; none of these guarantees bypasses.
 */
public final class BasicModules {
    private static final MovementPlanner.Spear SPEAR = new MovementPlanner.Spear();
    private static final MovementPlanner.Orbit ORBIT = new MovementPlanner.Orbit();
    private static ClientLevel lastLevel;
    private static UUID lockedTarget;
    private static V2 previousEnemy;
    private static boolean drivingUse;
    private static boolean drivingWalk;
    private static boolean drivingSneak;
    private static int floodTick;
    private static int eatTicks;
    private static double fallApex = Double.NaN;
    private static boolean bucketAttempted;

    private BasicModules() { }

    public static void tick(Minecraft client, ModuleCatalog catalog) {
        if (client.level != lastLevel) {
            lastLevel = client.level;
            reset(client);
            if (lastLevel != null) {
                if (catalog.guardCombat() != 0) BeegiClient.save();
            }
        }
        if (client.player == null || client.level == null || client.gameMode == null
                || client.gui.screen() != null) {
            releaseControls(client);
            return;
        }

        if (catalog.enabled("auto-sprint") && client.options.keyUp.isDown())
            client.player.setSprinting(true);
        holdWalk(client, catalog.enabled("auto-walk"));
        holdSneak(client, catalog.enabled("auto-sneak"));
        if (catalog.enabled("auto-jump") && client.player.onGround()
                && (client.options.keyUp.isDown() || client.options.keyLeft.isDown()
                || client.options.keyRight.isDown() || client.options.keyDown.isDown()))
            client.player.jumpFromGround();

        if (catalog.enabled("spear-rush")) spearRush(client, catalog);
        else if (catalog.enabled("target-orbit")) targetOrbit(client, catalog);
        else { releaseUse(client); lockedTarget = null; previousEnemy = null; SPEAR.reset(); ORBIT.reset(); }

        if (catalog.enabled("no-fall")) noFallWater(client);
        else { fallApex = Double.NaN; bucketAttempted = false; }

        if (catalog.enabled("block-flood")) blockFlood(client, catalog);
        if (catalog.enabled("auto-eat") && !catalog.enabled("spear-rush")) autoEat(client);
        else if (eatTicks > 0) { eatTicks = 0; if (!catalog.enabled("spear-rush")) releaseUse(client); }

        if (catalog.enabled("spear-rush")) return; // Spear's held-use attack conflicts with regular melee.
        boolean ready = catalog.enabled("rapid-charge")
                || client.player.getAttackStrengthScale(0.0F) >= .99F;
        if (!ready) return;
        if (catalog.enabled("rage-killaura")) {
            Player target = closest(client, catalog.effectiveScanRange(), false);
            if (target != null && client.player.hasLineOfSight(target)) { face(client, target); attack(client, target); return; }
        }
        if (catalog.enabled("kill-aura")) {
            Player target = closest(client, Math.min(6, catalog.effectiveScanRange()), true);
            if (target != null && client.player.hasLineOfSight(target)) { face(client, target); attack(client, target); return; }
        }
        if (catalog.enabled("triggerbot") && client.hitResult instanceof EntityHitResult hit
                && hit.getEntity() instanceof Player target && valid(client, target)) {
            attack(client, target);
        }
    }

    private static void face(Minecraft client, Player target) {
        Vec3 from = client.player.getEyePosition();
        Vec3 to = target.getEyePosition();
        AimMath.Rotation angles = AimMath.aim(from.x, from.y, from.z, to.x, to.y, to.z);
        client.player.setYRot(angles.yaw());
        client.player.setXRot(angles.pitch());
    }

    private static void attack(Minecraft client, Player target) {
        client.gameMode.attack(client.player, target);
        client.player.swing(InteractionHand.MAIN_HAND);
    }

    private static boolean valid(Minecraft client, Player p) {
        return p != client.player && p.isAlive() && !p.isSpectator();
    }

    private static Player closest(Minecraft client, double radius, boolean forward) {
        Player best = null;
        double score = radius * radius;
        Vec3 eye = client.player.getEyePosition();
        Vec3 look = client.player.getLookAngle();
        for (Player p : client.level.players()) {
            if (!valid(client, p)) continue;
            double d2 = client.player.distanceToSqr(p);
            if (d2 >= score) continue;
            if (forward && p.getEyePosition().subtract(eye).normalize().dot(look) < .65) continue;
            score = d2;
            best = p;
        }
        return best;
    }

    private static Player acquireLocked(Minecraft client, ModuleCatalog catalog) {
        if (lockedTarget != null) {
            for (Player p : client.level.players())
                if (valid(client,p) && p.getUUID().equals(lockedTarget)) return p;
        }
        // Acquisition range is limited; established lock stays until death/unload.
        Player p = closest(client, Math.min(20, Math.max(8, catalog.effectiveScanRange())), false);
        if (p == null) { lockedTarget = null; previousEnemy = null; return null; }
        lockedTarget = p.getUUID();
        previousEnemy = null;
        SPEAR.reset(); ORBIT.reset();
        return p;
    }

    private static V2 pos(Player p) { return new V2(p.getX(), p.getZ()); }
    private static boolean free(Minecraft client, V2 direction) {
        Vec3 test = new Vec3(direction.x(), 0, direction.z());
        return client.level.noCollision(client.player, client.player.getBoundingBox().move(test));
    }
    private static void apply(Minecraft client, MovementPlanner.Decision decision) {
        Vec3 velocity = client.player.getDeltaMovement();
        client.player.setDeltaMovement(decision.velocity().x(), velocity.y,
                decision.velocity().z());
        if (decision.jump() && client.player.onGround()) client.player.jumpFromGround();
    }

    private static void spearRush(Minecraft client, ModuleCatalog c) {
        if (client.player.getMainHandItem().get(DataComponents.KINETIC_WEAPON) == null) {
            releaseUse(client);
            return;
        }
        Player target = acquireLocked(client, c);
        if (target == null) { releaseUse(client); return; }
        face(client, target);
        V2 self = pos(client.player), enemy = pos(target);
        V2 velocity = previousEnemy == null ? new V2(0,0) : enemy.minus(previousEnemy);
        previousEnemy = enemy;
        V2 heading = enemy.minus(self).unit();
        MovementPlanner.Decision motion = SPEAR.next(lockedTarget.toString(), self, enemy,
                velocity, free(client, heading.times(.45)),
                free(client, heading.rotate90().times(.45)),
                free(client, heading.rotate90().times(-.45)));
        // Normal item-use key is the actual spear kinetic charge mechanism.
        client.options.keyUse.setDown(true);
        drivingUse = true;
        apply(client, motion);
    }

    private static void targetOrbit(Minecraft client, ModuleCatalog catalog) {
        Player target = acquireLocked(client, catalog);
        if (target == null) return;
        V2 self = pos(client.player), enemy = pos(target);
        MovementPlanner.Decision motion = ORBIT.next(self, enemy,
                free(client, enemy.minus(self).rotate90().unit().times(.4)));
        apply(client, motion);
    }

    /** Water bucket MLG only. No local fall-distance spoofing or slow-fall deception. */
    private static void noFallWater(Minecraft client) {
        if (client.player.onGround() || client.player.isInWater()) {
            fallApex = Double.NaN;
            bucketAttempted = false;
            return;
        }
        double y = client.player.getY();
        Vec3 velocity = client.player.getDeltaMovement();
        if (Double.isNaN(fallApex) || y > fallApex) fallApex = y;
        if (velocity.y >= -.25 || fallApex - y < 3.5 || bucketAttempted) return;
        // Do not attempt packet-spoof tricks. Locate an actual reachable landing block.
        Vec3 start = client.player.position();
        HitResult ray = client.level.clip(new ClipContext(start,
                start.add(0,-4.5,0), ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, client.player));
        if (!(ray instanceof BlockHitResult block) || ray.getType() != HitResult.Type.BLOCK) return;
        int bucketSlot = -1;
        for (int i=0; i<9; i++) {
            if (client.player.getInventory().getItem(i).is(Items.WATER_BUCKET)) { bucketSlot=i; break; }
        }
        if (bucketSlot == -1) return;
        int original = client.player.getInventory().getSelectedSlot();
        try {
            client.player.getInventory().setSelectedSlot(bucketSlot);
            client.gameMode.useItemOn(client.player, InteractionHand.MAIN_HAND,
                    new BlockHitResult(block.getLocation(), Direction.UP, block.getBlockPos(), false));
            bucketAttempted = true;
        } finally { client.player.getInventory().setSelectedSlot(original); }
    }

    /** Uses only hotbar blocks; 16 attempts max/tick, no extra placement cooldown. */
    private static void blockFlood(Minecraft client, ModuleCatalog catalog) {
        int slot = -1;
        for (int i=0; i<9; i++) {
            ItemStack stack = client.player.getInventory().getItem(i);
            if (!stack.isEmpty() && stack.getItem() instanceof BlockItem) { slot = i; break; }
        }
        if (slot < 0) return;
        BlockPos foot = BlockPos.containing(client.player.getX(), client.player.getY(),client.player.getZ());
        // Keep whichever straight two-high corridor is actually unobstructed.
        // If none is available, do not build walls or ceilings near the player.
        FloodPlanner.Exit exit = FloodPlanner.Exit.NONE;
        for (FloodPlanner.Exit candidate : FloodPlanner.Exit.values()) {
            if (candidate == FloodPlanner.Exit.NONE) continue;
            boolean clear = true;
            for (int length = 1; length <= catalog.floodRadius(); length++) {
                BlockPos step = foot.offset(candidate.dx * length, 0, candidate.dz * length);
                if (!client.level.getBlockState(step).isAir()
                        || !client.level.getBlockState(step.above()).isAir()) {
                    clear = false;
                    break;
                }
            }
            if (clear) { exit = candidate; break; }
        }
        List<FloodPlanner.Cell> positions = FloodPlanner.candidates(catalog.floodRadius(), exit);
        int tries = 0;
        int oldSlot = client.player.getInventory().getSelectedSlot();
        try {
            client.player.getInventory().setSelectedSlot(slot);
            int offset = floodTick++ % Math.max(1,positions.size());
            for (int i=0; i<positions.size() && tries<16; i++) {
                FloodPlanner.Cell p = positions.get((i+offset)%positions.size());
                BlockPos goal = foot.offset(p.x(),p.y(),p.z());
                if (!client.level.getBlockState(goal).isAir()) continue;
                // Interaction must be anchored to a solid, existing neighbor.
                for (Direction side : Direction.values()) {
                    BlockPos support = goal.relative(side);
                    if (client.level.getBlockState(support).isAir()) continue;
                    if (client.player.distanceToSqr(goal.getX()+.5, goal.getY()+.5, goal.getZ()+.5) > 25) continue;
                    Vec3 click = Vec3.atCenterOf(support);
                    BlockHitResult hit = new BlockHitResult(click, side.getOpposite(), support, false);
                    client.gameMode.useItemOn(client.player, InteractionHand.MAIN_HAND, hit);
                    tries++;
                    break;
                }
            }
        } finally { client.player.getInventory().setSelectedSlot(oldSlot); }
    }

    /** Food must already be in the active hand; never moves non-hotbar inventory items. */
    private static void autoEat(Minecraft client) {
        ItemStack held = client.player.getMainHandItem();
        boolean hungry = client.player.getFoodData().getFoodLevel() < 15;
        if (hungry && held.get(DataComponents.FOOD) != null) {
            client.options.keyUse.setDown(true); drivingUse = true; eatTicks++;
        } else if (eatTicks > 0) { eatTicks=0; releaseUse(client); }
    }
    private static void holdWalk(Minecraft client, boolean on) {
        if (on) { client.options.keyUp.setDown(true); drivingWalk=true; }
        else if (drivingWalk) { client.options.keyUp.setDown(false); drivingWalk=false; }
    }
    private static void holdSneak(Minecraft client, boolean on) {
        if (on) { client.options.keyShift.setDown(true); drivingSneak=true; }
        else if (drivingSneak) { client.options.keyShift.setDown(false); drivingSneak=false; }
    }
    private static void releaseUse(Minecraft client) {
        if (drivingUse) { client.options.keyUse.setDown(false); drivingUse=false; }
    }
    private static void releaseControls(Minecraft client) {
        releaseUse(client); holdWalk(client, false); holdSneak(client, false);
    }
    private static void reset(Minecraft client) {
        releaseControls(client); lockedTarget = null; previousEnemy=null;
        SPEAR.reset(); ORBIT.reset(); fallApex=Double.NaN; bucketAttempted=false;
    }
}
