package com.beegi.client.core;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Properties;

/** Stable IDs, individually validated settings, and atomic writes. */
public final class ConfigStore {
    private final Path path;
    public ConfigStore(Path path) { this.path = path; }

    public void load(ModuleCatalog catalog) {
        if (!Files.isRegularFile(path)) return;
        Properties props = new Properties();
        try (InputStream in = Files.newInputStream(path)) {
            props.load(in);
            for (ModuleCatalog.Module module : catalog.modules()) {
                // Do not enable unknown/unlisted modules from the config file.
                module.setEnabled(Boolean.parseBoolean(props.getProperty("enabled." + module.id, "false")));
                module.setInPreset(Boolean.parseBoolean(props.getProperty("preset." + module.id, "false")));
            }
            // A bad slider value must not prevent the rest of the config loading.
            try { catalog.setRange(Double.parseDouble(props.getProperty("target.range", "3"))); }
            catch (IllegalArgumentException ex) {
                System.err.println("[Beegi] Invalid target.range; using default: " + ex);
            }
            try { catalog.setFloodRadius(Integer.parseInt(props.getProperty("flood.radius", "3"))); }
            catch (NumberFormatException ex) {
                System.err.println("[Beegi] Invalid flood.radius; using default: " + ex);
            }
            // Enforce exclusive movement and combat modes after loading old configs.
            if (catalog.enabled("rage-killaura")) catalog.setEnabled("rage-killaura", true);
            if (catalog.enabled("spear-rush")) catalog.setEnabled("spear-rush", true);
        } catch (IOException ex) {
            System.err.println("[Beegi] Config read failed: " + ex);
        }
    }

    public void save(ModuleCatalog catalog) {
        Properties props = new Properties();
        for (ModuleCatalog.Module module : catalog.modules()) {
            props.setProperty("enabled." + module.id, Boolean.toString(module.enabled()));
            props.setProperty("preset." + module.id, Boolean.toString(module.inPreset()));
        }
        props.setProperty("target.range", Double.toString(catalog.range()));
        props.setProperty("flood.radius", Integer.toString(catalog.floodRadius()));
        Path temp = null;
        try {
            Path parent = path.toAbsolutePath().getParent();
            Files.createDirectories(parent);
            temp = Files.createTempFile(parent, ".beegi-", ".tmp");
            try (OutputStream out = Files.newOutputStream(temp)) {
                props.store(out, "Beegi 26.3 source port");
            }
            try {
                Files.move(temp, path, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temp, path, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            System.err.println("[Beegi] Config write failed: " + ex);
        } finally {
            if (temp != null) try { Files.deleteIfExists(temp); } catch (IOException ignored) { }
        }
    }
}
