package com.beegi.client.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/** Version-independent module metadata and persisted state. All registered entries have source handlers. */
public final class ModuleCatalog {
    public enum Category { COMBAT, MOVEMENT, WORLD, CLIENT }

    public static final class Module {
        public final String id;
        public final String name;
        public final Category category;
        private boolean enabled;
        private boolean inPreset;

        public Module(String id, String name, Category category) {
            if (!id.matches("[a-z][a-z0-9]*(?:-[a-z0-9]+)*"))
                throw new IllegalArgumentException("Invalid stable id: " + id);
            this.id = id;
            this.name = Objects.requireNonNull(name);
            this.category = Objects.requireNonNull(category);
        }
        public boolean enabled() { return enabled; }
        public boolean inPreset() { return inPreset; }
        public void setEnabled(boolean value) { enabled = value; }
        public void setInPreset(boolean value) { inPreset = value; }
    }

    private final List<Module> modules = new ArrayList<>();
    private double range = 3.0;
    private int floodRadius = 3;
    private boolean presetEnabledGuard = true;

    public ModuleCatalog() {
        add("kill-aura", "Kill Aura", Category.COMBAT);
        add("rage-killaura", "Rage Kill Aura", Category.COMBAT);
        add("triggerbot", "TriggerBot", Category.COMBAT);
        add("target-range", "Target Scan Range", Category.COMBAT);
        add("rapid-charge", "Rapid Charge (client)", Category.COMBAT);
        add("target-orbit", "Target Orbit", Category.COMBAT);
        add("spear-rush", "Spear Rush", Category.COMBAT);
        add("auto-sprint", "Auto Sprint", Category.MOVEMENT);
        add("auto-walk", "Auto Walk", Category.MOVEMENT);
        add("auto-jump", "Auto Jump", Category.MOVEMENT);
        add("auto-sneak", "Auto Sneak", Category.MOVEMENT);
        add("no-fall", "No Fall (bucket landing)", Category.MOVEMENT);
        add("block-flood", "Block Flood", Category.WORLD);
        add("auto-eat", "Auto Eat (held food)", Category.WORLD);
        add("combat-guard", "Combat Guard (on world join)", Category.CLIENT);
    }
    private void add(String id, String name, Category category) { modules.add(new Module(id, name, category)); }
    public List<Module> modules() { return Collections.unmodifiableList(modules); }
    public List<Module> category(Category category) {
        List<Module> found = new ArrayList<>();
        for (Module module : modules) if (module.category == category) found.add(module);
        return found;
    }
    public Module get(String id) {
        for (Module module : modules) if (module.id.equals(id)) return module;
        throw new IllegalArgumentException("Unknown module: " + id);
    }
    public boolean enabled(String id) { return get(id).enabled(); }
    public void setEnabled(String id, boolean value) {
        get(id).setEnabled(value);
        if (value && id.equals("rage-killaura")) get("kill-aura").setEnabled(false);
        if (value && id.equals("kill-aura")) get("rage-killaura").setEnabled(false);
        if (value && id.equals("spear-rush")) get("target-orbit").setEnabled(false);
        if (value && id.equals("target-orbit")) get("spear-rush").setEnabled(false);
    }
    public double range() { return range; }
    public void setRange(double v) {
        if (!Double.isFinite(v)) throw new IllegalArgumentException("Non-finite range");
        range = Math.round(Math.max(3.0, Math.min(100.0, v)) * 10.0) / 10.0;
    }
    public double effectiveScanRange() { return enabled("target-range") ? range : 3.0; }
    public int floodRadius() { return floodRadius; }
    public void setFloodRadius(int v) { floodRadius = Math.max(2, Math.min(5, v)); }

    /** Apply selected modules; preserve unrelated enabled state. */
    public int applyPreset() {
        // Enabling one preset module may disable a conflicting one. Return the
        // number of modules that are actually newly enabled in the final state.
        java.util.Set<String> before = new java.util.HashSet<>();
        for (Module m : modules) if (m.enabled()) before.add(m.id);
        for (Module m : modules) if (m.inPreset()) setEnabled(m.id, true);
        int count = 0;
        for (Module m : modules) if (m.enabled() && !before.contains(m.id)) count++;
        return count;
    }
    /** Combat Guard disables active combat modules on world joins; preset restores on demand. */
    public int guardCombat() {
        if (!enabled("combat-guard")) return 0;
        int count = 0;
        for (Module m : modules) {
            if (m.category == Category.COMBAT && m.enabled()) { m.setEnabled(false); count++; }
        }
        return count;
    }
}
