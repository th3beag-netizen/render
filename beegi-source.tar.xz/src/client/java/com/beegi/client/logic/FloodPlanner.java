package com.beegi.client.logic;

import java.util.ArrayList;
import java.util.List;

/** Candidate placement positions that preserve headroom and a selected escape corridor. */
public final class FloodPlanner {
    private FloodPlanner() { }
    public record Cell(int x, int y, int z) { }
    public enum Exit {
        EAST(1, 0), WEST(-1, 0), SOUTH(0, 1), NORTH(0, -1), NONE(0, 0);
        public final int dx, dz;
        Exit(int dx, int dz) { this.dx = dx; this.dz = dz; }
    }
    public static boolean allowed(int x, int y, int z, Exit exit) {
        // Preserve all cells occupied by a player at their current location.
        if (Math.abs(x) <= 1 && Math.abs(z) <= 1 && y >= 0 && y <= 2) return false;
        // Reserve a full two-high walkway of width one from player to edge of fill radius.
        if (exit != Exit.NONE && y >= 0 && y <= 1) {
            if (exit.dx != 0 && z == 0 && x * exit.dx >= 0) return false;
            if (exit.dz != 0 && x == 0 && z * exit.dz >= 0) return false;
        }
        // No confirmed exit? Restrict to floor instead of walls/ceilings.
        return exit != Exit.NONE || y < 0;
    }
    /** Kept for the original pure-Java geometry tests. */
    public static boolean allowed(int x, int y, int z, boolean eastExitClear) {
        return allowed(x, y, z, eastExitClear ? Exit.EAST : Exit.NONE);
    }
    public static List<Cell> candidates(int radius, Exit exit) {
        radius = Math.max(2, Math.min(5, radius));
        List<Cell> all = new ArrayList<>();
        for (int y = -1; y <= 2; y++)
            for (int r = 0; r <= radius; r++)
                for (int x = -r; x <= r; x++)
                    for (int z = -r; z <= r; z++) {
                        if (Math.max(Math.abs(x), Math.abs(z)) != r || !allowed(x,y,z,exit)) continue;
                        all.add(new Cell(x,y,z));
                    }
        return all;
    }
    public static List<Cell> candidates(int radius, boolean eastExitClear) {
        return candidates(radius, eastExitClear ? Exit.EAST : Exit.NONE);
    }
}
