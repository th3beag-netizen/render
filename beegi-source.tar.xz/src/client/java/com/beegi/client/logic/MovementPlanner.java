package com.beegi.client.logic;

/** Pure Java movement decisions; no dependence on Minecraft rendering or mappings. */
public final class MovementPlanner {
    private MovementPlanner() {}
    public record V2(double x, double z) {
        public V2 plus(V2 v) { return new V2(x + v.x, z + v.z); }
        public V2 minus(V2 v) { return new V2(x - v.x, z - v.z); }
        public V2 times(double n) { return new V2(x * n, z * n); }
        public double norm() { return Math.hypot(x, z); }
        public V2 unit() { double d = norm(); return d < 1.0e-8 ? new V2(0,0) : times(1 / d); }
        public V2 rotate90() { return new V2(-z, x); }
    }
    public record Decision(V2 velocity, boolean jump, String phase) {}

    public static final class Spear {
        private int preparing;
        private int stuck;
        private int recovery;
        private int side = 1;
        private V2 prior = null;
        private double lastCommandSpeed;
        private String targetKey = "";

        public void reset() { preparing = 0; stuck = 0; recovery = 0; prior = null; lastCommandSpeed = 0; targetKey = ""; }
        /** ready means the charge item is equipped, being held and has had time to prime. */
        public Decision next(String key, V2 self, V2 opponent, V2 enemyVelocity,
                             boolean forwardFree, boolean leftFree, boolean rightFree) {
            if (!key.equals(targetKey)) { reset(); targetKey = key; }
            // Standing still while priming a charge is intentional; only declare
            // a collision after a substantial commanded movement makes no progress.
            if (prior != null && lastCommandSpeed > .18 && self.minus(prior).norm() < .04) stuck++;
            else stuck = 0;
            prior = self;
            V2 delta = opponent.plus(enemyVelocity.times(3)).minus(self);
            double d = delta.norm();
            V2 towards = delta.unit();
            if (recovery > 0) {
                recovery--;
                return decide(towards.rotate90().times(side * .29), false, "recover");
            }
            if (stuck >= 6 || !forwardFree) {
                stuck = 0;
                if (leftFree || rightFree) {
                    side = leftFree ? 1 : -1;
                    recovery = 6;
                    return decide(towards.rotate90().times(side * .32), true, "detour");
                }
                recovery = 5;
                return decide(towards.times(-.2), true, "blocked");
            }
            if (d < 5.5) {
                preparing = Math.min(preparing + 1, 30);
                return decide(towards.times(-.33), false, "make-runup");
            }
            if (d > 14) {
                preparing = Math.min(preparing + 1, 30);
                return decide(towards.times(.32), false, "track");
            }
            if (preparing < 20) {
                preparing++;
                return decide(towards.times(-.08), false, "prime");
            }
            // Keep the attack charging; do not hover or circle at contact distance.
            preparing = 20;
            return decide(towards.times(.66), false, "charge");
        }
        private Decision decide(V2 velocity, boolean jump, String phase) {
            lastCommandSpeed = velocity.norm();
            return new Decision(velocity, jump, phase);
        }
    }

    public static final class Orbit {
        private int stuck;
        private int side = 1;
        private V2 previous;
        public void reset() { stuck = 0; side = 1; previous = null; }
        public Decision next(V2 self, V2 target, boolean forwardFree) {
            if (previous != null && self.minus(previous).norm() < .035) stuck++; else stuck = 0;
            previous = self;
            if (stuck >= 6 || !forwardFree) { side = -side; stuck = 0; }
            V2 offset = target.minus(self);
            double d = offset.norm();
            V2 inward = offset.unit();
            // Tangential motion plus proportional feedback to a 2.6-block orbit radius.
            V2 velocity = inward.rotate90().times(.23 * side)
                    .plus(inward.times(Math.max(-.20, Math.min(.20, (d - 2.6) * .12))));
            return new Decision(velocity, !forwardFree, "orbit");
        }
    }
}
