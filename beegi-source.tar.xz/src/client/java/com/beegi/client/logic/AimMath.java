package com.beegi.client.logic;

/** Calculates vanilla-style player rotations without depending on Minecraft APIs. */
public final class AimMath {
    private AimMath() { }
    public record Rotation(float yaw, float pitch) { }

    /** Observer and target coordinates are eye positions. Pitch is clamped to [-90,90]. */
    public static Rotation aim(double ox, double oy, double oz,
                               double tx, double ty, double tz) {
        double dx = tx - ox, dy = ty - oy, dz = tz - oz;
        double horizontal = Math.hypot(dx, dz);
        if (!Double.isFinite(horizontal) || !Double.isFinite(dy) ||
                (horizontal < 1e-8 && Math.abs(dy) < 1e-8)) {
            return new Rotation(0, 0);
        }
        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal));
        return new Rotation(yaw, Math.max(-90f, Math.min(90f, pitch)));
    }
}
