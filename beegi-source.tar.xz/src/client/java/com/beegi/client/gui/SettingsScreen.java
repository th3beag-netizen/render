package com.beegi.client.gui;

import com.beegi.client.BeegiClient;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class SettingsScreen extends Screen {
    private final Screen parent;
    public SettingsScreen(Screen parent) { super(Component.literal("Beegi Settings")); this.parent=parent; }
    @Override protected void init(){
        int x=width/2;
        addRenderableWidget(Button.builder(Component.literal("Target scan -1"),b->changeRange(-1))
          .bounds(x-150,55,145,20).build());
        addRenderableWidget(Button.builder(Component.literal("Target scan +1"),b->changeRange(1))
          .bounds(x+5,55,145,20).build());
        addRenderableWidget(Button.builder(Component.literal("Block Flood radius -1"),b->changeRadius(-1))
          .bounds(x-150,100,145,20).build());
        addRenderableWidget(Button.builder(Component.literal("Block Flood radius +1"),b->changeRadius(1))
          .bounds(x+5,100,145,20).build());
        addRenderableWidget(Button.builder(Component.literal("Back"),b->onClose())
          .bounds(x-150,165,300,20).build());
    }
    private void changeRange(int delta){BeegiClient.CATALOG.setRange(BeegiClient.CATALOG.range()+delta);BeegiClient.save();rebuildWidgets();}
    private void changeRadius(int delta){BeegiClient.CATALOG.setFloodRadius(BeegiClient.CATALOG.floodRadius()+delta);BeegiClient.save();rebuildWidgets();}
    @Override public void extractRenderState(GuiGraphicsExtractor g,int mx,int my,float dt){
        super.extractRenderState(g,mx,my,dt);
        g.text(font,"Scan radius: "+BeegiClient.CATALOG.range()+" blocks (server hit range unchanged)",width/2-144,36,0xFFFFFFFF,true);
        g.text(font,"Block Flood radius: "+BeegiClient.CATALOG.floodRadius()+" blocks",width/2-94,83,0xFFFFFFFF,true);
        g.text(font,"Spear Rush auto-tunes movement; no manual sliders",width/2-140,140,0xFFFFDD88,true);
    }
    @Override public void onClose(){minecraft.gui.setScreen(parent);}
}
