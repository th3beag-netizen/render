package com.beegi.client.gui;

import com.beegi.client.BeegiClient;
import com.beegi.client.core.ModuleCatalog;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import java.util.List;

/** Page-based menu: categories remain accessible at small resolutions. */
public final class BeegiMenuScreen extends Screen {
    private final Screen parent;
    private ModuleCatalog.Category category;
    private int page;
    private static final int PAGE_SIZE = 7;

    public BeegiMenuScreen(Screen parent) {
        this(parent, ModuleCatalog.Category.COMBAT, 0);
    }
    public BeegiMenuScreen(Screen parent, ModuleCatalog.Category category, int page) {
        super(Component.literal("Beegi 26.3"));
        this.parent = parent;
        this.category = category;
        this.page = page;
    }

    @Override protected void init() {
        int center = width / 2;
        int x = center - 164;
        for (ModuleCatalog.Category cat : ModuleCatalog.Category.values()) {
            ModuleCatalog.Category selected = cat;
            addRenderableWidget(Button.builder(Component.literal(cat.name()), b -> {
                category = selected; page = 0; rebuildWidgets();
            }).bounds(x, 36, 82, 20).build());
            x += 82;
        }
        List<ModuleCatalog.Module> list = BeegiClient.CATALOG.category(category);
        page = Math.min(page, Math.max(0, (list.size()-1)/PAGE_SIZE));
        int y = 66;
        for (int i=page*PAGE_SIZE; i<Math.min(list.size(),(page+1)*PAGE_SIZE);i++) {
            ModuleCatalog.Module selected = list.get(i);
            addRenderableWidget(Button.builder(label(selected), b -> {
                BeegiClient.CATALOG.setEnabled(selected.id, !selected.enabled());
                BeegiClient.save(); rebuildWidgets();
            }).bounds(center-155,y,310,20).build());
            y += 23;
        }
        int bottom = Math.max(y + 4, 95);
        addRenderableWidget(Button.builder(Component.literal("< Previous"), b -> {page--; rebuildWidgets();})
                .bounds(center-155,bottom,98,20).build()).active = page > 0;
        addRenderableWidget(Button.builder(Component.literal("Next >"), b -> {page++; rebuildWidgets();})
                .bounds(center+57,bottom,98,20).build()).active = (page+1)*PAGE_SIZE < list.size();
        addRenderableWidget(Button.builder(Component.literal("Settings"),
                b -> minecraft.gui.setScreen(new SettingsScreen(this)))
                .bounds(center-155,bottom+25,150,20).build());
        addRenderableWidget(Button.builder(Component.literal("Preset selection"),
                b -> minecraft.gui.setScreen(new PresetScreen(this)))
                .bounds(center+5,bottom+25,150,20).build());
        addRenderableWidget(Button.builder(Component.literal("Restore selected preset"), b -> {
            BeegiClient.CATALOG.applyPreset(); BeegiClient.save(); rebuildWidgets();
        }).bounds(center-155,bottom+50,310,20).build());
        addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose())
                .bounds(center-155,bottom+75,310,20).build());
    }
    private static Component label(ModuleCatalog.Module m) {
        return Component.literal((m.enabled() ? "[ON]  " : "[OFF] ") + m.name);
    }
    @Override public void extractRenderState(GuiGraphicsExtractor g, int x, int y, float d) {
        super.extractRenderState(g,x,y,d);
        g.text(font,"Beegi 26.3 · Expanded source port · Unverified runtime",Math.max(4,width/2-154),14,0xFFE0F7FF,true);
    }
    @Override public void onClose() { minecraft.gui.setScreen(parent); }
}
