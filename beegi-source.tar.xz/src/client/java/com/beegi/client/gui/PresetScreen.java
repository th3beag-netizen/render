package com.beegi.client.gui;

import com.beegi.client.BeegiClient;
import com.beegi.client.core.ModuleCatalog;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import java.util.List;

/** Preset selector paginated independently of the ordinary menu. */
public final class PresetScreen extends Screen {
    private final Screen parent;
    private int page;
    public PresetScreen(Screen parent) { super(Component.literal("Beegi Combat Preset")); this.parent=parent; }
    @Override protected void init() {
        int center=width/2;
        List<ModuleCatalog.Module> list=BeegiClient.CATALOG.modules();
        int y=38;
        for(int i=page*7;i<Math.min(list.size(),(page+1)*7);i++) {
            ModuleCatalog.Module m=list.get(i);
            addRenderableWidget(Button.builder(Component.literal((m.inPreset()?"[SELECTED] ":"[       ] ")+m.name),b->{
                m.setInPreset(!m.inPreset()); BeegiClient.save(); rebuildWidgets();
            }).bounds(center-150,y,300,20).build());
            y+=23;
        }
        addRenderableWidget(Button.builder(Component.literal("<"),b->{page--;rebuildWidgets();})
            .bounds(center-150,y+4,65,20).build()).active=page>0;
        addRenderableWidget(Button.builder(Component.literal(">"),b->{page++;rebuildWidgets();})
            .bounds(center+85,y+4,65,20).build()).active=(page+1)*7<list.size();
        addRenderableWidget(Button.builder(Component.literal("Apply selected"),b->{
            BeegiClient.CATALOG.applyPreset();BeegiClient.save();onClose();
        }).bounds(center-150,y+29,300,20).build());
        addRenderableWidget(Button.builder(Component.literal("Back"),b->onClose())
            .bounds(center-150,y+54,300,20).build());
    }
    @Override public void onClose(){minecraft.gui.setScreen(parent);}
}
