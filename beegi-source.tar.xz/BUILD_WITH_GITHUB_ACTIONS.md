# Compile Beegi against Minecraft 26.3 (verification required)

This archive contains a source project, NOT a tested gameplay release.

## GitHub Actions (no Java or Gradle installation on your computer)

1. Create a new empty GitHub repository (private is fine).
2. Upload **the contents of this ZIP**, including the hidden `.github/workflows/build.yml` file, to its repository root.
3. Open the **Actions** tab, choose **Verify Beegi 26.3** and run the workflow (or use its initial push run).
4. Review the **Compile against Minecraft 26.3 and Fabric** step.
   - If it fails, the log contains the actual Mojang/API compiler errors requiring source changes. Do **not** install a jar from this ZIP; none is supplied.
   - If it succeeds, download the `beegi-26.3-built-jar` artifact. Pick the normal named jar rather than a `-sources.jar`.
5. Install a matching Minecraft 26.3 + Fabric Loader + Fabric API instance and test in an expendable single-player world. Compile success alone does not mean gameplay works.

## Local build

Requires Java 25, Gradle 9.7.1 or compatible and working download access to Minecraft and Fabric Maven.

```sh
bash test-core.sh
gradle --no-daemon clean build
gradle runClient
```

**Current authoring environment:** JDK 21, no Gradle, no DNS access to Fabric Maven. The steps above have not run here against Minecraft 26.3. No installable JAR is being claimed.
