import com.beegi.client.core.ConfigStore;
import com.beegi.client.core.ModuleCatalog;
import java.nio.file.Files;
import java.nio.file.Path;

public class ModuleCatalogTest {
    public static void main(String[] args) throws Exception {
        ModuleCatalog catalog = new ModuleCatalog();
        if (catalog.effectiveScanRange() != 3.0) throw new AssertionError();
        catalog.setRange(400.0);
        if (catalog.range() != 100.0) throw new AssertionError("max range");
        catalog.setRange(-1);
        if (catalog.range() != 3.0) throw new AssertionError("min range");
        catalog.get("rage-killaura").setInPreset(true);
        catalog.get("triggerbot").setEnabled(true);
        if (catalog.applyPreset() != 1) throw new AssertionError("preset application");
        if (!catalog.get("triggerbot").enabled()) throw new AssertionError("preset reset other module");
        Path p = Files.createTempDirectory("beegi-test").resolve("config/beegi.properties");
        ConfigStore store = new ConfigStore(p);
        store.save(catalog);
        ModuleCatalog restored = new ModuleCatalog();
        store.load(restored);
        if (!restored.get("rage-killaura").enabled() || !restored.get("rage-killaura").inPreset()) throw new AssertionError("reload");
        // One malformed value must not prevent other saved module states loading.
        Files.writeString(p, "enabled.combat-guard=true\ntarget.range=NaN\nflood.radius=not-a-number\n");
        ModuleCatalog broken = new ModuleCatalog();
        store.load(broken);
        if (!broken.enabled("combat-guard")) throw new AssertionError("partial config recovery");
        if (broken.range() != 3.0 || broken.floodRadius() != 3)
            throw new AssertionError("malformed settings should leave defaults intact");
        System.out.println("PASS: stable IDs, range limits, preset conflicts, atomic persistence, config recovery");
    }
}
