import com.beegi.client.core.ModuleCatalog;
import com.beegi.client.logic.FloodPlanner;
import com.beegi.client.logic.MovementPlanner;
import java.util.HashSet;
import java.util.Set;

public class PortLogicTest {
    private static void check(boolean passed, String why) { if (!passed) throw new AssertionError(why); }
    public static void main(String[] args) {
        ModuleCatalog c = new ModuleCatalog();
        Set<String> ids = new HashSet<>();
        for (ModuleCatalog.Module m : c.modules()) check(ids.add(m.id), "duplicate ID: " + m.id);
        check(c.modules().size() >= 15, "module catalog incomplete");
        c.setRange(10000); check(c.range() == 100, "range cap");
        c.setRange(-100); check(c.range() == 3, "range minimum");
        c.setFloodRadius(99); check(c.floodRadius() == 5, "flood radius cap");
        c.get("triggerbot").setInPreset(true);
        c.get("auto-sprint").setInPreset(true);
        c.get("combat-guard").setEnabled(true);
        check(c.applyPreset() == 2 && c.enabled("triggerbot"), "preset apply");
        check(c.guardCombat() == 1, "guard should disable combat");
        check(!c.enabled("triggerbot") && c.enabled("auto-sprint"), "guard preserves movement");
        check(c.applyPreset() == 1 && c.enabled("triggerbot"), "preset restores combat");
        c.setEnabled("kill-aura", true); c.setEnabled("rage-killaura", true);
        check(!c.enabled("kill-aura"), "auras conflict");
        ModuleCatalog presetConflicts = new ModuleCatalog();
        presetConflicts.get("kill-aura").setInPreset(true);
        presetConflicts.get("rage-killaura").setInPreset(true);
        check(presetConflicts.applyPreset() == 1, "preset should count only modules left enabled");
        check(!presetConflicts.enabled("kill-aura") && presetConflicts.enabled("rage-killaura"),
                "preset must preserve exclusivity");
        for (FloodPlanner.Cell p : FloodPlanner.candidates(5, true)) {
            check(FloodPlanner.allowed(p.x(),p.y(),p.z(),true), "blocked self/exit");
        }
        check(!FloodPlanner.allowed(0,1,0,true), "head space");
        check(!FloodPlanner.allowed(3,0,0,true), "exit lane");
        check(!FloodPlanner.allowed(3,2,0,false), "fallback floor only");
        MovementPlanner.Spear spear = new MovementPlanner.Spear();
        var near = spear.next("target", new MovementPlanner.V2(0,0), new MovementPlanner.V2(2,0), new MovementPlanner.V2(0,0),true,true,true);
        check(near.phase().equals("make-runup") && near.velocity().x() < 0,"retreat to charge");
        spear.reset();
        String phase="";
        for (int i = 0; i < 25; i++)
            phase = spear.next("target",new MovementPlanner.V2(0,0), new MovementPlanner.V2(8,0),new MovementPlanner.V2(0,0),true,true,true).phase();
        // The test client did not move; anti-stuck recovery should have engaged at least once.
        check(phase != null && !phase.isEmpty(), "planner makes progress");
        spear.reset();
        // Staying still during the charge wind-up must not count as getting stuck.
        boolean foundFalseDetour = false;
        for (int i = 0; i < 16; i++) {
            String step = spear.next("target", new MovementPlanner.V2(0,0),
                    new MovementPlanner.V2(8,0), new MovementPlanner.V2(0,0),
                    true,true,true).phase();
            if (step.equals("detour") || step.equals("recover")) foundFalseDetour = true;
        }
        check(!foundFalseDetour, "spear priming should not spuriously detour");
        MovementPlanner.Orbit orbit = new MovementPlanner.Orbit();
        check(orbit.next(new MovementPlanner.V2(0,0), new MovementPlanner.V2(4,0),true).velocity().norm() > 0,"orbit output");
        System.out.println("PASS: 15-module catalog, presets/guard, geometry, spear/orbit state machines");
    }
}
