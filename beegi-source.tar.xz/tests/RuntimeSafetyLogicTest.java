import com.beegi.client.logic.FloodPlanner;
import com.beegi.client.logic.AimMath;

public final class RuntimeSafetyLogicTest {
    static void check(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        for (var exit : FloodPlanner.Exit.values()) {
            var candidates = FloodPlanner.candidates(5, exit);
            check(!candidates.isEmpty(), "missing candidates " + exit);
            for (var cell : candidates) {
                check(FloodPlanner.allowed(cell.x(), cell.y(), cell.z(), exit), "unsafe candidate " + cell);
                check(!(Math.abs(cell.x()) <= 1 && Math.abs(cell.z()) <= 1 && cell.y() >= 0 && cell.y() <= 2), "player overlap");
            }
            for (int d = 0; d <= 5; d++) for (int y = 0; y <= 1; y++) {
                if (exit != FloodPlanner.Exit.NONE)
                    check(!FloodPlanner.allowed(exit.dx * d, y, exit.dz * d, exit), "exit corridor blocked");
            }
        }
        check(!FloodPlanner.allowed(2, 0, 0, FloodPlanner.Exit.NONE), "must not wall player with unknown exit");
        check(FloodPlanner.allowed(2, -1, 0, FloodPlanner.Exit.NONE), "floor filling still allowed");
        var east = AimMath.aim(0,0,0,1,0,0);
        var south = AimMath.aim(0,0,0,0,0,1);
        var west = AimMath.aim(0,0,0,-1,0,0);
        var north = AimMath.aim(0,0,0,0,0,-1);
        check(Math.abs(east.yaw() + 90) < .001, "east yaw");
        check(Math.abs(south.yaw()) < .001, "south yaw");
        check(Math.abs(west.yaw() - 90) < .001, "west yaw");
        check(Math.abs(north.yaw() + 180) < .001, "north yaw");
        check(AimMath.aim(0,0,0,0,3,0).pitch() == -90, "vertical pitch");
        check(AimMath.aim(0,0,0,0,-3,0).pitch() == 90, "downward pitch");
        System.out.println("PASS: four-direction exit corridors and full-circle aiming");
    }
}
