#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
javac -d "$TMP" src/client/java/com/beegi/client/core/{ModuleCatalog,ConfigStore}.java \
  src/client/java/com/beegi/client/logic/{MovementPlanner,FloodPlanner,AimMath}.java \
  tests/{ModuleCatalogTest,PortLogicTest,RuntimeSafetyLogicTest}.java
java -cp "$TMP" ModuleCatalogTest
java -cp "$TMP" PortLogicTest
java -cp "$TMP" RuntimeSafetyLogicTest
python - <<'PYTEST'
from pathlib import Path
import csv,re
root=Path.cwd()
rows=list(csv.DictReader((root/'MODULE_INVENTORY.csv').open()))
assert len(rows)>=149
ids=re.findall(r'add\("([a-z][a-z0-9-]+)"', (root/'src/client/java/com/beegi/client/core/ModuleCatalog.java').read_text())
assert len(ids)==len(set(ids))==15, ids
for key in ['net.fabricmc.fabric.api.client.screen.v1.ScreenEvents','net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents']:
    assert key in (root/'src/client/java/com/beegi/client/BeegiClient.java').read_text(),key
print('PASS: 26.3 event import fixes, 15 unique module IDs, inventory entries:',len(rows))
PYTEST
