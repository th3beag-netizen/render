# Beegi 26.3 Phase 2: terrain-mesh Xray and 3D wireframe ESP

## What is actually implemented
- Chunk meshing override **only on RenderSectionRegion snapshots**, not in the ClientLevel. Hides non-whitelisted terrain as air while Xray is active. Keeps existing vanilla ore textures and collision.
- Detects xray enablement/filter changes once per client tick, debounces for 3 ticks and triggers `Minecraft.levelExtractor.allChanged()` to rebuild chunk meshes. This can temporarily stutter when changing Xray filters.
- Selectable ores: diamond, ancient debris, emerald, gold, iron, redstone, coal, lapis, copper and quartz; optional storage retention. Disabling Xray restores ordinary chunk rendering after rebuild.
- Camera-space 3D wireframe outlines made of the 12 actual 3D AABB edges, near-plane clipping, optional tracers, distances, adjustable width. **Uses a HUD projection; does not depth-test against vanilla world meshes.**
- GUI toggle, opacity controls, scanner settings, expanded ore lists, line width and theme persist in BeegiOptions.

## Known limitations
- Compiling is not runtime testing. Launch the client in a test world, toggle Xray on/off, visit chunk boundaries, and verify that normal terrain returns after disabling it.
- Shader/Sodium render compatibility not verified; shader mods may need separate integration.
- Vanilla servers can hide ores from the client using server-side anti-Xray. No client-side Xray can reveal missing server data.
- Xray opacity controls overlay transparency, not actual world terrain transparency. Terrain is currently hidden or fully visible.
- 3D ESP boxes are perspective-projected on HUD, not GL world-space line render passes, to avoid the rapidly changing 26.3 scene pipeline; labels and colors still work.
