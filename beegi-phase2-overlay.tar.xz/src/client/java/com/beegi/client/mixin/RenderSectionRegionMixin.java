package com.beegi.client.mixin;

import com.beegi.client.render.XrayRuntime;
import net.minecraft.client.renderer.chunk.RenderSectionRegion;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Changes ONLY section mesh input; the real ClientLevel stays untouched. */
@Mixin(RenderSectionRegion.class)
public abstract class RenderSectionRegionMixin {
    @Inject(method = "getBlockState", at = @At("RETURN"), cancellable = true)
    private void beegi$xrayMeshMask(BlockPos pos, CallbackInfoReturnable<BlockState> cir) {
        if (XrayRuntime.active.enabled()) cir.setReturnValue(XrayRuntime.meshState(cir.getReturnValue()));
    }
}
