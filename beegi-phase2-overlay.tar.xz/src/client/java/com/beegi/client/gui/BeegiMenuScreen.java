package com.beegi.client.gui;

import com.beegi.client.BeegiClient;
import com.beegi.client.core.BeegiOptions;
import com.beegi.client.core.FloatingLayout;
import com.beegi.client.core.ModuleCatalog;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.function.BooleanSupplier;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;

/**
 * Peegi-style floating category windows.  Every control is a real input target:
 * headers drag, module rows toggle, right-click opens an editable inspector,
 * category windows scroll independently, sliders drag and settings persist.
 * No ImGui dependency: the UI is rendered with the 26.3 native extraction API.
 */
public final class BeegiMenuScreen extends Screen {
    private static final int TOP = 49;
    private static final int ROW = 27;
    private static final int HEAD = 38;
    private static final int GAP = 12;
    private static final int[] PALETTE = {0xFFB7A4FF, 0xFF79E7F3, 0xFFFFA6CF};
    private final Screen parent;
    private final FloatingLayout.Rect[] panels = new FloatingLayout.Rect[ModuleCatalog.Category.values().length];
    private final int[] scroll = new int[panels.length];
    private final boolean[] folded = new boolean[panels.length];
    private final List<Integer> zOrder = new ArrayList<>();
    private String query = "";
    private String selected = "xray";
    private EditBox search;
    private int dragPanel = -1;
    private boolean dragInspector;
    private int draggingSlider = -1;
    private int inspectorScroll;
    private boolean inspectorOpen;
    private FloatingLayout.Rect inspector;
    private int panelWidth, panelHeight;
    private int mouseX, mouseY;

    private static final int BG=0xFA10131C, PANEL=0xF31A1E29, CARD=0xF1262A36;
    private static final int EDGE=0xFF434657, MUTED=0xFF9699B0, WHITE=0xFFEDF0F9, OFF=0xFF6F7588;
    private static final int HOVER=0xFF33374A;

    public BeegiMenuScreen(Screen parent) {
        super(Component.literal("Beegi / Peegi-style Click GUI"));
        this.parent = parent;
    }
    public BeegiMenuScreen(Screen parent, ModuleCatalog.Category ignored, int unused) { this(parent); }

    @Override protected void init() {
        int sw=width, sh=height;
        float scale=BeegiOptions.uiScale/100f;
        panelWidth=Math.min(sw-14,Math.max(130,Math.round(178*scale)));
        int cols=Math.max(1,Math.min(panels.length,(sw-16+GAP)/(panelWidth+GAP)));
        int rows=(panels.length+cols-1)/cols;
        panelHeight=Math.max(105,Math.min(Math.round(313*scale),(sh-TOP-26-(rows-1)*GAP)/rows));
        panelHeight=Math.min(panelHeight,sh-TOP-8);
        for(int i=0;i<panels.length;i++) {
            FloatingLayout.Rect auto=FloatingLayout.home(i,panels.length,sw,sh,panelWidth,panelHeight,TOP);
            int px=BeegiOptions.panelX[i], py=BeegiOptions.panelY[i];
            panels[i]=px<0||py<0?auto:FloatingLayout.within(new FloatingLayout.Rect(px,py,panelWidth,panelHeight),sw,sh,TOP);
            if(!zOrder.contains(i)) zOrder.add(i);
        }
        int iw=Math.min(326,sw-18),ih=Math.min(490,sh-TOP-10);
        int ix=BeegiOptions.inspectorX<0?Math.max(5,(sw-iw)/2):BeegiOptions.inspectorX;
        int iy=BeegiOptions.inspectorY<0?Math.max(TOP,(sh-ih)/2):BeegiOptions.inspectorY;
        inspector=FloatingLayout.within(new FloatingLayout.Rect(ix,iy,iw,ih),sw,sh,TOP);
        search=new EditBox(font,165,17,Math.max(65,Math.min(175,sw-425)),18,Component.literal("Search all modules"));
        search.setValue(query);
        search.setResponder(v -> { query=v.toLowerCase(Locale.ROOT).trim(); clampScroll(); });
        search.setHint(Component.literal("Search modules..."));
        addRenderableWidget(search);
    }

    private void persistLayout() {
        for(int i=0;i<panels.length;i++) { BeegiOptions.panelX[i]=panels[i].x(); BeegiOptions.panelY[i]=panels[i].y(); }
        BeegiOptions.inspectorX=inspector.x(); BeegiOptions.inspectorY=inspector.y();
        BeegiOptions.save();
    }
    private static boolean hit(double x,double y,int l,int t,int r,int b) {
        return x>=l&&x<r&&y>=t&&y<b;
    }
    private int accent(){return PALETTE[Math.floorMod(BeegiOptions.theme,3)];}
    private static int alpha(int rgb,int a){return ((a&255)<<24)|(rgb&0xFFFFFF);}
    private void rect(GuiGraphicsExtractor g,int x,int y,int w,int h,int color) {
        if(w>0&&h>0)g.fill(x,y,x+w,y+h,color);
    }
    private void text(GuiGraphicsExtractor g,String s,int x,int y,int color){g.text(font,s,x,y,color,true);}
    private String ellipsis(String s,int px) {
        if(px<14)return "";
        while(s.length()>2&&font.width(s)>px-8)s=s.substring(0,s.length()-1);
        return s;
    }
    private List<ModuleCatalog.Module> entries(int category) {
        List<ModuleCatalog.Module> out=new ArrayList<>();
        for(ModuleCatalog.Module m:BeegiClient.CATALOG.modules()) {
            if(m.category.ordinal()!=category)continue;
            if(!query.isEmpty()&&!m.name.toLowerCase(Locale.ROOT).contains(query)&&!m.id.contains(query))continue;
            out.add(m);
        }
        out.sort(Comparator.comparing(m->m.name));
        return out;
    }
    private int visible(FloatingLayout.Rect p) {return Math.max(1,(p.h()-HEAD-12)/ROW);}
    private void clampScroll() {
        for(int i=0;i<panels.length;i++) {
            scroll[i]=Math.max(0,Math.min(scroll[i],Math.max(0,entries(i).size()-visible(panels[i]))));
        }
    }
    private void panel(GuiGraphicsExtractor g,int i) {
        FloatingLayout.Rect r=panels[i]; int x=r.x(),y=r.y(),w=r.w(),h=r.h();
        ModuleCatalog.Category cat=ModuleCatalog.Category.values()[i];
        int displayH=folded[i]?HEAD:h;
        rect(g,x+5,y+7,w,displayH,0x66000000);
        rect(g,x,y,w,displayH,PANEL);
        rect(g,x,y,w,2,accent());
        rect(g,x,y+2,w,HEAD-2,0xFF232534);
        rect(g,x+10,y+11,3,17,accent());
        text(g,cat.name(),x+20,y+13,WHITE);
        List<ModuleCatalog.Module> modules=entries(i);
        text(g,String.format(Locale.ROOT,"%02d",modules.size()),x+w-37,y+13,MUTED);
        text(g,folded[i]?"+":"-",x+w-13,y+13,WHITE);
        rect(g,x+8,y+HEAD-1,w-16,1,EDGE);
        if(folded[i]) return;
        int n=visible(r), begin=Math.min(scroll[i],Math.max(0,modules.size()-n));
        for(int j=0;j<n&&begin+j<modules.size();j++) {
            ModuleCatalog.Module m=modules.get(begin+j); int yy=y+HEAD+j*ROW+4;
            boolean hovered=hit(mouseX,mouseY,x+7,yy,x+w-7,yy+ROW-3)&&!inspectorOpen;
            rect(g,x+7,yy,w-14,ROW-3,hovered?HOVER:CARD);
            rect(g,x+7,yy,m.enabled()?3:2,ROW-3,m.enabled()?accent():OFF);
            text(g,ellipsis(m.name,w-55),x+17,yy+8,m.enabled()?WHITE:MUTED);
            text(g,m.enabled()?"ON":"OFF",x+w-32,yy+8,m.enabled()?accent():OFF);
            if(m.id.equals(selected))rect(g,x+7,yy+ROW-4,w-14,1,alpha(accent(),160));
        }
        if(modules.size()>n){
            int trackY=y+HEAD+4,trackH=h-HEAD-10;
            int thumbH=Math.max(17,trackH*n/modules.size());
            int thumbY=trackY+(trackH-thumbH)*begin/Math.max(1,modules.size()-n);
            rect(g,x+w-3,trackY,2,trackH,0xFF333649);
            rect(g,x+w-3,thumbY,2,thumbH,accent());
        }
        if(modules.isEmpty())text(g,"No matches",x+19,y+HEAD+20,MUTED);
    }
    private void topButton(GuiGraphicsExtractor g,String title,int x,int w) {
        boolean hover=hit(mouseX,mouseY,x,12,x+w,37);
        rect(g,x,12,w,25,hover?HOVER:0xFF282B38);
        rect(g,x,35,w,2,hover?accent():EDGE);
        text(g,title,x+9,20,hover?WHITE:MUTED);
    }
    @Override public void extractRenderState(GuiGraphicsExtractor g,int mx,int my,float delta) {
        this.mouseX=mx;this.mouseY=my;
        rect(g,0,0,width,height,0xB7080B12);
        rect(g,0,0,width,45,0xF5151723);
        rect(g,0,43,width,2,accent());
        text(g,"B E E G I",13,13,accent());
        text(g,"26.3",13,28,MUTED);
        text(g,"/",149,20,MUTED);
        int close=width-55, preset=width-124, theme=width-211, reset=width-284;
        topButton(g,"Reset",reset,67);
        topButton(g,"Theme",theme,81);
        topButton(g,"Preset",preset,63);
        topButton(g,"Close",close,50);
        for(int i:zOrder)panel(g,i);
        if(inspectorOpen)inspector(g);
        if(BeegiClient.CATALOG.enabled("xray")) text(g,"XRAY ACTIVE  /  CHUNK MESH MASK",Math.max(10,width-230),height-13,accent());
        if(BeegiOptions.showWatermark) text(g,"BEEGI  •  DRAG WINDOWS  /  LEFT TO TOGGLE  /  RIGHT TO EDIT  /  SCROLL TO BROWSE",10,height-13,MUTED);
        super.extractRenderState(g,mx,my,delta);
    }

    private interface Op {
        String name();
        void draw(GuiGraphicsExtractor g,int x,int y,int w,boolean hover);
        void activate(double x,int left,int w);
        boolean slider();
    }
    private final class Toggle implements Op {
        private final String name; private final BooleanSupplier state; private final Runnable action;
        Toggle(String name,BooleanSupplier state,Runnable action){this.name=name;this.state=state;this.action=action;}
        public String name(){return name;}
        public void draw(GuiGraphicsExtractor g,int x,int y,int w,boolean hover) {
            rect(g,x,y,w,33,hover?HOVER:CARD);
            text(g,ellipsis(name,w-65),x+10,y+12,WHITE);
            rect(g,x+w-44,y+10,33,14,state.getAsBoolean()?alpha(accent(),210):0xFF555B70);
            rect(g,x+w-(state.getAsBoolean()?25:42),y+12,10,10,WHITE);
        }
        public void activate(double px,int left,int w){action.run();changed();}
        public boolean slider(){return false;}
    }
    private final class Range implements Op {
        private final String name; private final DoubleSupplier state; private final DoubleConsumer setter;
        private final double min,max,step;
        Range(String name,DoubleSupplier get,DoubleConsumer set,double min,double max,double step){
            this.name=name;this.state=get;this.setter=set;this.min=min;this.max=max;this.step=step;
        }
        public String name(){return name;}
        public void draw(GuiGraphicsExtractor g,int x,int y,int w,boolean hover) {
            rect(g,x,y,w,42,hover?HOVER:CARD);
            text(g,ellipsis(name,w-75),x+10,y+8,WHITE);
            double value=state.getAsDouble();
            String val=step<1?String.format(Locale.ROOT,"%.2f",value):Integer.toString((int)Math.round(value));
            text(g,val,x+w-13-font.width(val),y+8,accent());
            int trackX=x+11,trackW=w-22,ty=y+31;
            rect(g,trackX,ty,trackW,3,0xFF505367);
            int filled=(int)Math.round(trackW*FloatingLayout.fraction(value,min,max));
            rect(g,trackX,ty,filled,3,accent());
            rect(g,trackX+filled-2,ty-3,6,9,WHITE);
        }
        public void activate(double px,int left,int w) {
            setter.accept(FloatingLayout.slider(px,left+11,w-22,min,max,step));
        }
        public boolean slider(){return true;}
    }
    private void changed(){BeegiOptions.save();BeegiClient.save();}
    private List<Op> ops() {
        List<Op> list=new ArrayList<>();
        final String id=selected;
        ModuleCatalog.Module module=BeegiClient.CATALOG.get(id);
        list.add(new Toggle("Module enabled",()->module.enabled(),()->BeegiClient.CATALOG.setEnabled(id,!module.enabled())));
        list.add(new Toggle("Combat preset",module::inPreset,()->module.setInPreset(!module.inPreset())));
        switch(id){
            case "xray", "block-esp" -> {
                list.add(new Range("Scan radius (blocks)",()->BeegiOptions.oreRadius,v->BeegiOptions.oreRadius=(int)v,6,32,1));
                list.add(new Range("Overlay opacity",()->BeegiOptions.opacity,v->BeegiOptions.opacity=(int)v,20,100,5));
                list.add(new Toggle("Exposed ores only",()->BeegiOptions.exposedOnly,()->BeegiOptions.exposedOnly=!BeegiOptions.exposedOnly));
                list.add(new Toggle("Show block labels",()->BeegiOptions.showLabels,()->BeegiOptions.showLabels=!BeegiOptions.showLabels));
                list.add(new Toggle("Diamond ore",()->BeegiOptions.diamond,()->BeegiOptions.diamond=!BeegiOptions.diamond));
                list.add(new Toggle("Ancient debris",()->BeegiOptions.ancient,()->BeegiOptions.ancient=!BeegiOptions.ancient));
                list.add(new Toggle("Emerald ore",()->BeegiOptions.emerald,()->BeegiOptions.emerald=!BeegiOptions.emerald));
                list.add(new Toggle("Gold ore",()->BeegiOptions.gold,()->BeegiOptions.gold=!BeegiOptions.gold));
                list.add(new Toggle("Iron ore",()->BeegiOptions.iron,()->BeegiOptions.iron=!BeegiOptions.iron));
                list.add(new Toggle("Redstone ore",()->BeegiOptions.redstone,()->BeegiOptions.redstone=!BeegiOptions.redstone));
                list.add(new Toggle("Coal ore",()->BeegiOptions.coal,()->BeegiOptions.coal=!BeegiOptions.coal));
                list.add(new Toggle("Lapis ore",()->BeegiOptions.lapis,()->BeegiOptions.lapis=!BeegiOptions.lapis));
                list.add(new Toggle("Copper ore",()->BeegiOptions.copper,()->BeegiOptions.copper=!BeegiOptions.copper));
                list.add(new Toggle("Nether quartz",()->BeegiOptions.quartz,()->BeegiOptions.quartz=!BeegiOptions.quartz));
                if(id.equals("xray")) {
                    list.add(new Toggle("Keep storage visible",()->BeegiOptions.xrayStorage,()->BeegiOptions.xrayStorage=!BeegiOptions.xrayStorage));
                    list.add(new Toggle("Overlay wireframes",()->BeegiOptions.xrayDrawOutlines,()->BeegiOptions.xrayDrawOutlines=!BeegiOptions.xrayDrawOutlines));
                }
                list.add(new Toggle("3D wireframe boxes",()->BeegiOptions.esp3d,()->BeegiOptions.esp3d=!BeegiOptions.esp3d));
                list.add(new Toggle("Tracers",()->BeegiOptions.espTracers,()->BeegiOptions.espTracers=!BeegiOptions.espTracers));
            }
            case "storage-esp" -> {
                list.add(new Range("Scan radius",()->BeegiOptions.oreRadius,v->BeegiOptions.oreRadius=(int)v,6,32,1));
                list.add(new Toggle("Chests",()->BeegiOptions.chest,()->BeegiOptions.chest=!BeegiOptions.chest));
                list.add(new Toggle("Barrels",()->BeegiOptions.barrel,()->BeegiOptions.barrel=!BeegiOptions.barrel));
                list.add(new Toggle("Shulker boxes",()->BeegiOptions.shulker,()->BeegiOptions.shulker=!BeegiOptions.shulker));
                list.add(new Toggle("3D wireframe boxes",()->BeegiOptions.esp3d,()->BeegiOptions.esp3d=!BeegiOptions.esp3d));
                list.add(new Toggle("Tracers",()->BeegiOptions.espTracers,()->BeegiOptions.espTracers=!BeegiOptions.espTracers));
            }
            case "esp" -> {
                list.add(new Range("Player detection range",()->BeegiOptions.espRange,v->BeegiOptions.espRange=(int)v,8,128,1));
                list.add(new Toggle("Player labels",()->BeegiOptions.showLabels,()->BeegiOptions.showLabels=!BeegiOptions.showLabels));
                list.add(new Toggle("Show distances",()->BeegiOptions.espDistance,()->BeegiOptions.espDistance=!BeegiOptions.espDistance));
                list.add(new Toggle("3D wireframe boxes",()->BeegiOptions.esp3d,()->BeegiOptions.esp3d=!BeegiOptions.esp3d));
                list.add(new Toggle("Tracers",()->BeegiOptions.espTracers,()->BeegiOptions.espTracers=!BeegiOptions.espTracers));
                list.add(new Range("Line width",()->BeegiOptions.espLineWidth,v->BeegiOptions.espLineWidth=(int)v,1,3,1));
            }
            case "fly" -> {
                list.add(new Range("Horizontal speed",()->BeegiOptions.flySpeed,v->BeegiOptions.flySpeed=v,.1,1.4,.05));
                list.add(new Range("Vertical speed",()->BeegiOptions.flyVertical,v->BeegiOptions.flyVertical=v,.1,1.4,.05));
            }
            case "block-flood" -> list.add(new Range("Block placement radius",()->BeegiClient.CATALOG.floodRadius(),v->BeegiClient.CATALOG.setFloodRadius((int)v),2,5,1));
            case "target-range" -> list.add(new Range("Target scan distance",()->BeegiClient.CATALOG.range(),v->BeegiClient.CATALOG.setRange(v),3,100,1));
        }
        return list;
    }
    private int rowHeight(Op op){return op.slider()?49:40;}
    private void inspector(GuiGraphicsExtractor g) {
        FloatingLayout.Rect r=inspector;
        int x=r.x(),y=r.y(),w=r.w(),h=r.h();
        rect(g,x+7,y+8,w,h,0xA0000000);
        rect(g,x,y,w,h,BG);
        rect(g,x,y,w,3,accent());
        rect(g,x,y+3,w,45,0xFF292C3B);
        text(g,"MODULE SETTINGS",x+14,y+14,accent());
        text(g,"X",x+w-23,y+14,WHITE);
        ModuleCatalog.Module m=BeegiClient.CATALOG.get(selected);
        text(g,ellipsis(m.name,w-26),x+14,y+59,WHITE);
        text(g,m.category.name()+"  /  " + (m.enabled()?"ENABLED":"DISABLED"),x+14,y+76,m.enabled()?accent():MUTED);
        rect(g,x+10,y+98,w-20,1,EDGE);
        int cy=y+110, bottom=y+h-77;
        List<Op> rows=ops();
        int shown=0;
        for(int i=inspectorScroll;i<rows.size();i++) {
            Op op=rows.get(i);int oh=rowHeight(op);
            if(cy+oh>bottom)break;
            boolean hover=hit(mouseX,mouseY,x+12,cy,x+w-12,cy+oh-5);
            op.draw(g,x+12,cy,w-24,hover);cy+=oh;shown++;
        }
        if(shown==0)text(g,"Scroll to view controls",x+16,cy+7,MUTED);
        rect(g,x+12,y+h-67,w-24,1,EDGE);
        if(selected.equals("xray")) {
            text(g,"Xray hides non-selected terrain meshes.",x+15,y+h-55,MUTED);
            text(g,"Disable to rebuild normal chunks.",x+15,y+h-40,MUTED);
        } else if(selected.equals("fly")) {
            text(g,"Space / Shift  •  Up / Down",x+15,y+h-51,MUTED);
            text(g,"Servers can reject flight.",x+15,y+h-36,MUTED);
        } else {
            text(g,"Left click: change  •  Drag: adjust",x+15,y+h-45,MUTED);
        }
    }
    private void pickPanel(int i){zOrder.remove((Integer)i);zOrder.add(i);}
    private void resetPanels(){
        BeegiOptions.resetLayout();
        for(int i=0;i<panels.length;i++)panels[i]=FloatingLayout.home(i,panels.length,width,height,panelWidth,panelHeight,TOP);
        persistLayout();
    }
    private boolean topAction(double x,double y) {
        if(y<12||y>=38)return false;
        if(hit(x,y,width-55,12,width-5,37)){onClose();return true;}
        if(hit(x,y,width-124,12,width-61,37)){BeegiClient.CATALOG.applyPreset();changed();return true;}
        if(hit(x,y,width-211,12,width-130,37)){BeegiOptions.nextTheme();return true;}
        if(hit(x,y,width-284,12,width-217,37)){resetPanels();return true;}
        return false;
    }
    @Override public boolean mouseClicked(MouseButtonEvent e,boolean doubleClick) {
        double x=e.x(), y=e.y(); int button=e.button();
        if(search!=null&&search.isMouseOver(x,y)) return super.mouseClicked(e,doubleClick);
        if(button==0&&topAction(x,y))return true;
        if(inspectorOpen) {
            FloatingLayout.Rect r=inspector;
            if(r.contains(x,y)){
                if(button==0&&hit(x,y,r.x()+r.w()-32,r.y()+3,r.x()+r.w(),r.y()+40)){
                    inspectorOpen=false;draggingSlider=-1;return true;
                }
                if(button==0&&hit(x,y,r.x(),r.y(),r.x()+r.w()-33,r.y()+48)) {
                    dragInspector=true;return true;
                }
                int cy=r.y()+110;
                List<Op> rows=ops();
                for(int i=inspectorScroll;i<rows.size();i++){
                    Op op=rows.get(i);
                    int oh=rowHeight(op);
                    if(cy+oh>r.y()+r.h()-77)break;
                    if(button==0&&hit(x,y,r.x()+12,cy,r.x()+r.w()-12,cy+oh-5)){
                        op.activate(x,r.x()+12,r.w()-24);
                        if(op.slider())draggingSlider=i;
                        changed();
                        return true;
                    }
                    cy+=oh;
                }
                return true;
            }
            if(button==0||button==1)inspectorOpen=false;
        }
        for(int ord=zOrder.size()-1;ord>=0;ord--) {
            int i=zOrder.get(ord);
            FloatingLayout.Rect p=panels[i];
            if(!hit(x,y,p.x(),p.y(),p.x()+p.w(),p.y()+(folded[i]?HEAD:p.h())))continue;
            pickPanel(i);
            if(y<p.y()+HEAD) {
                if(button==0&&x>=p.x()+p.w()-25){folded[i]=!folded[i];return true;}
                if(button==0){dragPanel=i;return true;}
                return true;
            }
            List<ModuleCatalog.Module> entries=entries(i);
            int row=(int)(y-p.y()-HEAD-4)/ROW;
            if(row>=0&&row<visible(p)){
                int idx=scroll[i]+row;
                if(idx<entries.size()){
                    ModuleCatalog.Module module=entries.get(idx);
                    selected=module.id;
                    if(button==1||x>=p.x()+p.w()-40){
                        inspectorOpen=true;inspectorScroll=0;
                        return true;
                    }
                    if(button==0){BeegiClient.CATALOG.setEnabled(selected,!module.enabled());changed();return true;}
                }
            }
            return true;
        }
        return super.mouseClicked(e,doubleClick);
    }
    @Override public boolean mouseDragged(MouseButtonEvent e,double dx,double dy) {
        if(dragPanel>=0){
            panels[dragPanel]=FloatingLayout.translate(panels[dragPanel],dx,dy,width,height,TOP);
            return true;
        }
        if(dragInspector){inspector=FloatingLayout.translate(inspector,dx,dy,width,height,TOP);return true;}
        if(draggingSlider>=0&&inspectorOpen){
            List<Op> rows=ops();
            if(draggingSlider<rows.size())rows.get(draggingSlider).activate(e.x(),inspector.x()+12,inspector.w()-24);
            return true;
        }
        return super.mouseDragged(e,dx,dy);
    }
    @Override public boolean mouseReleased(MouseButtonEvent e) {
        if(dragPanel>=0||dragInspector||draggingSlider>=0){
            dragPanel=-1;dragInspector=false;draggingSlider=-1;
            persistLayout();BeegiClient.save();
            return true;
        }
        return super.mouseReleased(e);
    }
    @Override public boolean mouseScrolled(double x,double y,double scrollX,double scrollY) {
        if(inspectorOpen&&inspector.contains(x,y)){
            int capacity=0,available=inspector.h()-187;
            for(Op op:ops())capacity+=rowHeight(op);
            int max=Math.max(0,ops().size()-Math.max(1,available/42));
            inspectorScroll=FloatingLayout.clamp(inspectorScroll-(int)Math.signum(scrollY),0,max);
            return true;
        }
        for(int ord=zOrder.size()-1;ord>=0;ord--){
            int i=zOrder.get(ord);
            if(!folded[i]&&panels[i].contains(x,y)){
                scroll[i]=FloatingLayout.clamp(scroll[i]-(int)Math.signum(scrollY),0,Math.max(0,entries(i).size()-visible(panels[i])));
                return true;
            }
        }
        return super.mouseScrolled(x,y,scrollX,scrollY);
    }
    @Override public void onClose(){persistLayout();BeegiClient.save();minecraft.gui.setScreen(parent);}
}
