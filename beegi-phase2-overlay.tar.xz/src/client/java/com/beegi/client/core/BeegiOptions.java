package com.beegi.client.core;

import net.fabricmc.loader.api.FabricLoader;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Shared, persistent visual / movement settings for the Peegi-style Beegi UI. */
public final class BeegiOptions {
    private BeegiOptions() {}
    public static int theme = 0; // 0 lunar violet, 1 glacier cyan, 2 rose
    public static final int PANEL_COUNT = 5;
    public static final int[] panelX = {-1,-1,-1,-1,-1};
    public static final int[] panelY = {-1,-1,-1,-1,-1};
    public static int inspectorX = -1, inspectorY = -1;
    public static int uiScale = 100;
    public static boolean showWatermark = true;
    public static void resetLayout() {
        java.util.Arrays.fill(panelX, -1);
        java.util.Arrays.fill(panelY, -1);
        inspectorX = inspectorY = -1;
        save();
    }
    public static int oreRadius = 18;
    public static int espRange = 64;
    public static int opacity = 80;
    public static boolean exposedOnly = false;
    public static boolean showLabels = true;
    public static boolean diamond = true, ancient = true, emerald = true;
    public static boolean gold = true, iron = true, redstone = true;
    public static boolean chest = true, barrel = true, shulker = true;
    public static boolean coal = false, lapis = false, copper = false, quartz = false;
    public static boolean xrayStorage = true;
    public static boolean xrayDrawOutlines = false;
    public static boolean esp3d = true, espTracers = false, espDistance = true;
    public static int espLineWidth = 2;
    public static double flySpeed = 0.38, flyVertical = 0.32;
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("beegi-visuals.properties");

    public static int accent() { return switch (theme) {
        case 1 -> 0xFF66D8EC;
        case 2 -> 0xFFF592C1;
        default -> 0xFFB8A0FF;
    }; }
    public static String themeName() { return switch (theme) {
        case 1 -> "Glacier"; case 2 -> "Rose"; default -> "Moonlight";
    }; }
    public static int panel() { return 0xF0181B2C; }
    public static int card() { return 0xF124293C; }
    public static int muted() { return 0xFF9DA7C1; }
    public static int text() { return 0xFFF1F1FF; }
    public static int clamp(int n, int lo, int hi) { return Math.min(hi, Math.max(lo, n)); }
    public static double clamp(double n, double lo, double hi) { return Math.min(hi, Math.max(lo, n)); }
    public static void nextTheme() { theme = (theme + 1) % 3; save(); }

    public static void load() {
        if (!Files.isRegularFile(FILE)) return;
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(FILE)) {
            p.load(in);
            theme = clamp(number(p, "theme", 0), 0, 2);
            uiScale = clamp(number(p, "uiScale", 100), 75, 125);
            showWatermark = yes(p, "showWatermark", true);
            inspectorX = number(p, "inspectorX", -1);
            inspectorY = number(p, "inspectorY", -1);
            for (int i=0; i<PANEL_COUNT; i++) {
                panelX[i] = number(p, "panel."+i+".x", -1);
                panelY[i] = number(p, "panel."+i+".y", -1);
            }
            oreRadius = clamp(number(p, "oreRadius", 18), 6, 32);
            espRange = clamp(number(p, "espRange", 64), 8, 128);
            opacity = clamp(number(p, "opacity", 80), 20, 100);
            flySpeed = clamp(decimal(p, "flySpeed", .38), .10, 1.4);
            flyVertical = clamp(decimal(p, "flyVertical", .32), .10, 1.4);
            exposedOnly = yes(p, "exposedOnly", false);
            showLabels = yes(p, "showLabels", true);
            diamond = yes(p, "diamond", true); ancient = yes(p, "ancient", true);
            emerald = yes(p, "emerald", true); gold = yes(p, "gold", true);
            iron = yes(p, "iron", true); redstone = yes(p, "redstone", true);
            chest = yes(p, "chest", true); barrel = yes(p, "barrel", true); shulker = yes(p, "shulker", true);
            coal = yes(p,"coal",false); lapis = yes(p,"lapis",false);
            copper = yes(p,"copper",false); quartz = yes(p,"quartz",false);
            xrayStorage = yes(p,"xrayStorage",true); xrayDrawOutlines = yes(p,"xrayDrawOutlines",false);
            esp3d = yes(p,"esp3d",true); espTracers = yes(p,"espTracers",false);
            espDistance = yes(p,"espDistance",true); espLineWidth = clamp(number(p,"espLineWidth",2),1,3);
        } catch (Exception e) { System.err.println("[Beegi] Visual config: " + e.getMessage()); }
    }
    private static int number(Properties p, String k, int d) { try { return Integer.parseInt(p.getProperty(k, Integer.toString(d))); } catch(Exception e) { return d; } }
    private static double decimal(Properties p, String k, double d) { try { double v = Double.parseDouble(p.getProperty(k, Double.toString(d))); return Double.isFinite(v) ? v : d; } catch(Exception e) { return d; } }
    private static boolean yes(Properties p, String k, boolean d) { return Boolean.parseBoolean(p.getProperty(k, Boolean.toString(d))); }
    public static void save() {
        Properties p = new Properties();
        p.setProperty("theme", ""+theme);
        p.setProperty("uiScale", ""+uiScale);
        p.setProperty("showWatermark", ""+showWatermark);
        p.setProperty("inspectorX", ""+inspectorX);
        p.setProperty("inspectorY", ""+inspectorY);
        for (int i=0; i<PANEL_COUNT; i++) {
            p.setProperty("panel."+i+".x", Integer.toString(panelX[i]));
            p.setProperty("panel."+i+".y", Integer.toString(panelY[i]));
        } p.setProperty("oreRadius", ""+oreRadius); p.setProperty("espRange", ""+espRange);
        p.setProperty("opacity", ""+opacity); p.setProperty("flySpeed", ""+flySpeed); p.setProperty("flyVertical", ""+flyVertical);
        p.setProperty("exposedOnly", ""+exposedOnly); p.setProperty("showLabels", ""+showLabels);
        p.setProperty("diamond", ""+diamond); p.setProperty("ancient", ""+ancient);
        p.setProperty("emerald", ""+emerald); p.setProperty("gold", ""+gold); p.setProperty("iron", ""+iron);
        p.setProperty("redstone", ""+redstone); p.setProperty("chest", ""+chest);
        p.setProperty("barrel", ""+barrel); p.setProperty("shulker", ""+shulker);
        p.setProperty("coal", ""+coal);p.setProperty("lapis", ""+lapis);
        p.setProperty("copper", ""+copper);p.setProperty("quartz", ""+quartz);
        p.setProperty("xrayStorage", ""+xrayStorage);p.setProperty("xrayDrawOutlines", ""+xrayDrawOutlines);
        p.setProperty("esp3d", ""+esp3d);p.setProperty("espTracers", ""+espTracers);
        p.setProperty("espDistance", ""+espDistance);p.setProperty("espLineWidth", ""+espLineWidth);
        try {
            Files.createDirectories(FILE.getParent());
            try (OutputStream out = Files.newOutputStream(FILE)) { p.store(out, "Beegi appearance and visual module settings"); }
        } catch (Exception e) { System.err.println("[Beegi] Could not save appearance: " + e.getMessage()); }
    }
}
