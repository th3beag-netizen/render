package com.beegi.client.modules;

import com.beegi.client.BeegiClient;
import com.beegi.client.core.ModuleCatalog;
import com.beegi.client.core.BeegiOptions;
import com.beegi.client.render.ProjectionMath;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.Minecraft;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * Beegi 26.3 ESP and Fly additions.
 * ESP is an honest HUD projection of loaded client-side entities and blocks; it
 * does not reveal unloaded or server-hidden data. All scanners are bounded.
 */
public final class BeegiAddons {
    private static final int MAX_ORES = 220;
    private static final int MAX_STORAGES = 100;
    private record Marker(BlockPos pos, String name, int color) {}
    private static final List<Marker> ORES = new ArrayList<>();
    private static final List<Marker> STORAGES = new ArrayList<>();
    private static Object lastLevel;
    private static int ticks;

    private BeegiAddons() {}

    public static void registerHud() {
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath("beegi", "esp_overlay"), BeegiAddons::drawHud);
    }

    public static void tick(Minecraft mc, ModuleCatalog catalog) {
        if (mc.level != lastLevel) {
            lastLevel = mc.level;
            ORES.clear();
            STORAGES.clear();
            ticks = 0;
        }
        if (mc.player == null || mc.level == null) return;
        if (mc.gui.screen() == null && catalog.enabled("fly")
                && !catalog.enabled("target-orbit") && !catalog.enabled("spear-rush")) fly(mc);
        ticks++;
        if (!catalog.enabled("block-esp") && !catalog.enabled("storage-esp") && !catalog.enabled("xray")) {
            ORES.clear();
            STORAGES.clear();
            return;
        }
        if (ticks % 25 == 1) scan(mc, catalog);
    }

    /** Normal collision and server movement validation still apply. */
    private static void fly(Minecraft mc) {
        double forward = (mc.options.keyUp.isDown() ? 1 : 0)
                - (mc.options.keyDown.isDown() ? 1 : 0);
        double strafe = (mc.options.keyRight.isDown() ? 1 : 0)
                - (mc.options.keyLeft.isDown() ? 1 : 0);
        double scale = Math.hypot(forward, strafe);
        if (scale > 0) { forward /= scale; strafe /= scale; }
        double yaw = Math.toRadians(mc.player.getYRot());
        double vx = (-Math.sin(yaw) * forward - Math.cos(yaw) * strafe) * BeegiOptions.flySpeed;
        double vz = ( Math.cos(yaw) * forward - Math.sin(yaw) * strafe) * BeegiOptions.flySpeed;
        double vy = mc.options.keyJump.isDown() ? BeegiOptions.flyVertical :
                mc.options.keyShift.isDown() ? -BeegiOptions.flyVertical : 0.0;
        mc.player.setDeltaMovement(vx, vy, vz);
        mc.player.fallDistance = 0.0f; // local visual state; server may still apply fall damage
    }

    /** Scan only client-loaded blocks in a bounded cube; all filters are live. */
    private static void scan(Minecraft mc, ModuleCatalog catalog) {
        ORES.clear(); STORAGES.clear();
        BlockPos origin = mc.player.blockPosition();
        boolean ores = catalog.enabled("block-esp") || catalog.enabled("xray");
        boolean storage = catalog.enabled("storage-esp");
        int radius = BeegiOptions.oreRadius;
        int yRadius = Math.min(12, radius);
        for (int y = -yRadius; y <= yRadius; y++)
            for (int x = -radius; x <= radius; x++)
                for (int z = -radius; z <= radius; z++) {
                    if ((!ores || ORES.size() >= MAX_ORES)
                            && (!storage || STORAGES.size() >= MAX_STORAGES)) return;
                    if(x*x+z*z>radius*radius) continue;
                    BlockPos pos = origin.offset(x, y, z);
                    if (!mc.level.hasChunkAt(pos)) continue;
                    BlockState state = mc.level.getBlockState(pos);
                    if (ores && ORES.size() < MAX_ORES) {
                        Marker ore = ore(pos, state);
                        if (ore != null && (!BeegiOptions.exposedOnly || exposed(mc,pos))) ORES.add(ore);
                    }
                    if (storage && STORAGES.size() < MAX_STORAGES) {
                        Marker hit = storage(pos,state);
                        if (hit != null) STORAGES.add(hit);
                    }
                }
    }
    private static boolean exposed(Minecraft mc, BlockPos p) {
        return mc.level.getBlockState(p.above()).isAir() || mc.level.getBlockState(p.below()).isAir()
                || mc.level.getBlockState(p.north()).isAir() || mc.level.getBlockState(p.south()).isAir()
                || mc.level.getBlockState(p.east()).isAir() || mc.level.getBlockState(p.west()).isAir();
    }
    private static Marker ore(BlockPos pos, BlockState s) {
        if (BeegiOptions.diamond && (s.is(Blocks.DIAMOND_ORE) || s.is(Blocks.DEEPSLATE_DIAMOND_ORE))) return new Marker(pos,"Diamond",0xFF58E1E7);
        if (BeegiOptions.ancient && s.is(Blocks.ANCIENT_DEBRIS)) return new Marker(pos,"Ancient debris",0xFFCB91FF);
        if (BeegiOptions.emerald && (s.is(Blocks.EMERALD_ORE) || s.is(Blocks.DEEPSLATE_EMERALD_ORE))) return new Marker(pos,"Emerald",0xFF60E7A8);
        if (BeegiOptions.gold && (s.is(Blocks.GOLD_ORE) || s.is(Blocks.DEEPSLATE_GOLD_ORE))) return new Marker(pos,"Gold",0xFFFFD76D);
        if (BeegiOptions.iron && (s.is(Blocks.IRON_ORE) || s.is(Blocks.DEEPSLATE_IRON_ORE))) return new Marker(pos,"Iron",0xFFD5DBE6);
        if (BeegiOptions.redstone && (s.is(Blocks.REDSTONE_ORE) || s.is(Blocks.DEEPSLATE_REDSTONE_ORE))) return new Marker(pos,"Redstone",0xFFFF6778);
        return null;
    }
    private static Marker storage(BlockPos pos, BlockState s) {
        Block b = s.getBlock();
        if (BeegiOptions.chest && (b == Blocks.CHEST || b == Blocks.TRAPPED_CHEST || b == Blocks.ENDER_CHEST)) return new Marker(pos,"Chest",0xFFFFC87A);
        if (BeegiOptions.barrel && b == Blocks.BARREL) return new Marker(pos,"Barrel",0xFFFFB37D);
        if (BeegiOptions.shulker && b instanceof ShulkerBoxBlock) return new Marker(pos,"Shulker",0xFFC2A2FF);
        return null;
    }

    public static void drawHud(GuiGraphicsExtractor g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || mc.gui.screen() != null) return;
        ModuleCatalog catalog = BeegiClient.CATALOG;
        int width = mc.getWindow().getGuiScaledWidth();
        int height = mc.getWindow().getGuiScaledHeight();
        Vec3 eye = mc.player.getEyePosition();
        if (catalog.enabled("esp")) {
            for (Player player : mc.level.players()) {
                if (player == mc.player || !player.isAlive() || player.isSpectator()) continue;
                if (eye.distanceToSqr(player.position()) > BeegiOptions.espRange * BeegiOptions.espRange) continue;
                drawProjected(g, mc, eye, width, height, player.getBoundingBox(), 0xFF4DDEFF,
                        player.getName().getString() + (BeegiOptions.espDistance
                           ? "  " + (int)Math.sqrt(eye.distanceToSqr(player.position())) + "m" : ""));
            }
        }
        if (catalog.enabled("block-esp") || (catalog.enabled("xray") && BeegiOptions.xrayDrawOutlines)) {
            int shown = 0;
            for (Marker ore : ORES) {
                if (++shown > 100) break; // cap frame cost
                drawProjected(g, mc, eye, width, height,
                    new AABB(ore.pos()), opacity(ore.color()), ore.name());
            }
        }
        if (catalog.enabled("storage-esp")) {
            int shown = 0;
            for (Marker box : STORAGES) {
                if (++shown > 75) break;
                drawProjected(g, mc, eye, width, height,
                    new AABB(box.pos()), opacity(box.color()), box.name());
            }
        }
    }

    private static int opacity(int color) {return ((BeegiOptions.opacity * 255 / 100) << 24) | (color & 0xFFFFFF);}
    /** True 3D AABB wireframe, projected from camera space to HUD pixels. */
    private static void drawProjected(GuiGraphicsExtractor g, Minecraft mc, Vec3 eye,
                                      int width, int height, AABB box, int color, String label) {
        double yaw = mc.player.getYRot(), pitch = mc.player.getXRot();
        double fov = mc.options.fov().get();
        ProjectionMath.Camera[] corners = new ProjectionMath.Camera[8];
        double minX=Double.POSITIVE_INFINITY,minY=Double.POSITIVE_INFINITY;
        double maxX=Double.NEGATIVE_INFINITY,maxY=Double.NEGATIVE_INFINITY;
        double[] xx={box.minX,box.maxX},yy={box.minY,box.maxY},zz={box.minZ,box.maxZ};
        boolean visible=false;
        for(int ix=0;ix<2;ix++)for(int iy=0;iy<2;iy++)for(int iz=0;iz<2;iz++){
            int idx=(ix<<2)|(iy<<1)|iz;
            corners[idx]=ProjectionMath.camera(xx[ix]-eye.x, yy[iy]-eye.y, zz[iz]-eye.z, yaw,pitch);
            var projected=ProjectionMath.screen(corners[idx],width,height,fov);
            if(projected!=null){
                visible=true;
                minX=Math.min(minX,projected.x());minY=Math.min(minY,projected.y());
                maxX=Math.max(maxX,projected.x());maxY=Math.max(maxY,projected.y());
            }
        }
        if(!visible)return;
        if(BeegiOptions.esp3d){
            for(int i=0;i<8;i++) for(int bit=0;bit<3;bit++){
                int j=i^(1<<bit);
                if(i>j)continue;
                var line=ProjectionMath.edge(corners[i],corners[j],width,height,fov);
                if(line!=null)drawLine(g,line.a().x(),line.a().y(),line.b().x(),line.b().y(),width,height,color);
            }
        } else {
            int l=(int)Math.max(0,Math.min(width-1,minX));
            int t=(int)Math.max(0,Math.min(height-1,minY));
            int r=(int)Math.max(0,Math.min(width,maxX));
            int b=(int)Math.max(0,Math.min(height,maxY));
            if(r-l<3||b-t<3)return;
            g.fill(l,t,r,t+2,color);g.fill(l,b-2,r,b,color);
            g.fill(l,t,l+2,b,color);g.fill(r-2,t,r,b,color);
        }
        if(BeegiOptions.espTracers){
            double tx=(minX+maxX)/2.0,ty=(minY+maxY)/2.0;
            drawLine(g,width/2.0,height-7,tx,ty,width,height,color);
        }
        if(BeegiOptions.showLabels && Double.isFinite(minY) && Double.isFinite(minX)){
            int tx=(int)Math.max(1,Math.min(width-1,minX));
            int ty=(int)Math.max(1,Math.min(height-12,minY-12));
            g.text(mc.font,label,tx,ty,color|0xFF000000,true);
        }
    }

    /** Liang–Barsky clip before bounded DDA to keep behind-camera projections cheap. */
    private static void drawLine(GuiGraphicsExtractor g,double x0,double y0,double x1,double y1,
                                 int width,int height,int color){
        double dx=x1-x0,dy=y1-y0;
        double[] p={-dx,dx,-dy,dy},q={x0,width-1-x0,y0,height-1-y0};
        double lo=0,hi=1;
        for(int i=0;i<4;i++){
            if(Math.abs(p[i])<1.0e-9){if(q[i]<0)return;continue;}
            double t=q[i]/p[i];
            if(p[i]<0)lo=Math.max(lo,t);else hi=Math.min(hi,t);
            if(lo>hi)return;
        }
        double ax=x0+dx*lo,ay=y0+dy*lo,bx=x0+dx*hi,by=y0+dy*hi;
        int n=(int)Math.ceil(Math.max(Math.abs(bx-ax),Math.abs(by-ay)));
        if(n>1200)n=1200;
        int stroke=BeegiOptions.espLineWidth;
        for(int i=0;i<=n;i++){
            double t=n==0?0.0:i/(double)n;
            int px=(int)Math.round(ax+(bx-ax)*t),py=(int)Math.round(ay+(by-ay)*t);
            if(px>=0&&px<width&&py>=0&&py<height) g.fill(px,py,Math.min(width,px+stroke),Math.min(height,py+stroke),color);
        }
    }

}
