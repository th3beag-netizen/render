package com.beegi.client;

import com.beegi.client.core.ConfigStore;
import com.beegi.client.core.BeegiOptions;
import com.beegi.client.core.ModuleCatalog;
import com.beegi.client.gui.BeegiMenuScreen;
import com.beegi.client.modules.BasicModules;
import com.beegi.client.modules.BeegiAddons;
import com.beegi.client.render.XrayRuntime;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.resources.Identifier;

public final class BeegiClient implements ClientModInitializer {
    public static final ModuleCatalog CATALOG = new ModuleCatalog();
    private static final ConfigStore CONFIG = new ConfigStore(
            FabricLoader.getInstance().getConfigDir().resolve("beegi.properties"));

    public static void save() { CONFIG.save(CATALOG); }

    @Override
    public void onInitializeClient() {
        CONFIG.load(CATALOG);
        BeegiOptions.load();
        BeegiAddons.registerHud();

        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath("beegi", "controls"));
        KeyMapping openMenu = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.beegi.open_menu", InputConstants.Type.KEYBOARD,
                InputConstants.KEY_RSHIFT, category));
        KeyMapping applyPreset = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.beegi.apply_preset", InputConstants.Type.KEYBOARD,
                InputConstants.KEY_P, category));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenu.consumeClick()) {
                // The title screen has its own handler because normal key bindings are
                // often not consumed by the game while a vanilla screen is open.
                if (client.gui.screen() == null) {
                    client.gui.setScreen(new BeegiMenuScreen(null));
                }
            }
            while (applyPreset.consumeClick()) {
                CATALOG.applyPreset();
                save();
            }
            BasicModules.tick(client, CATALOG);
            BeegiAddons.tick(client, CATALOG);
            XrayRuntime.tick(client, CATALOG);
        });

        ScreenEvents.BEFORE_INIT.register((client, screen, width, height) -> {
            if (!(screen instanceof TitleScreen)) return;
            ScreenKeyboardEvents.beforeKeyPress(screen).register((s, keyEvent) -> {
                if (openMenu.matches(keyEvent)) {
                    client.gui.setScreen(new BeegiMenuScreen(screen));
                }
            });
        });
    }
}
