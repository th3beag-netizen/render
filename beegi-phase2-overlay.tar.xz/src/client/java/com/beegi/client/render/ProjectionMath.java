package com.beegi.client.render;

/** Camera-space perspective and near-plane clipped wireframe segments. No game dependencies. */
public final class ProjectionMath {
    private ProjectionMath() {}
    public record Camera(double right, double up, double depth) {}
    public record Screen(double x, double y) {}
    public record Edge(Screen a, Screen b) {}
    public static Camera camera(double dx, double dy, double dz, double yawDegrees, double pitchDegrees) {
        double yaw=Math.toRadians(yawDegrees), pitch=Math.toRadians(pitchDegrees);
        double sy=Math.sin(yaw),cy=Math.cos(yaw),sp=Math.sin(pitch),cp=Math.cos(pitch);
        return new Camera(dx*(-cy)+dz*(-sy),dx*(-sy*sp)+dy*cp+dz*(cy*sp),
                          dx*(-sy*cp)+dy*(-sp)+dz*(cy*cp));
    }
    public static Screen screen(Camera p,int width,int height,double fovDegrees) {
        if(p.depth()<0.05 || !Double.isFinite(p.depth()))return null;
        double focal=height/(2.0*Math.tan(Math.toRadians(Math.max(30,Math.min(110,fovDegrees)))/2));
        return new Screen(width/2.0 + p.right()/p.depth()*focal,height/2.0-p.up()/p.depth()*focal);
    }
    public static Edge edge(Camera a,Camera b,int width,int height,double fovDegrees) {
        final double near=0.06;
        if(a.depth()<near&&b.depth()<near)return null;
        if(a.depth()<near){double t=(near-a.depth())/(b.depth()-a.depth());a=lerp(a,b,t);}
        if(b.depth()<near){double t=(near-b.depth())/(a.depth()-b.depth());b=lerp(b,a,t);}
        Screen s=screen(a,width,height,fovDegrees),t=screen(b,width,height,fovDegrees);
        if(s==null||t==null)return null;
        if(Math.max(s.x,t.x)<0||Math.min(s.x,t.x)>width||Math.max(s.y,t.y)<0||Math.min(s.y,t.y)>height)return null;
        return new Edge(s,t);
    }
    private static Camera lerp(Camera a,Camera b,double t) {
        return new Camera(a.right()+(b.right()-a.right())*t,a.up()+(b.up()-a.up())*t,a.depth()+(b.depth()-a.depth())*t);
    }
}
