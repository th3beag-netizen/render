package com.beegi.client.render;

import com.beegi.client.core.BeegiOptions;
import com.beegi.client.core.ModuleCatalog;
import net.minecraft.client.Minecraft;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.world.level.block.state.BlockState;

/** Immutable cross-thread Xray mask. Only terrain mesh snapshots are changed. */
public final class XrayRuntime {
    private XrayRuntime() { }
    public record Filter(boolean enabled, boolean diamond, boolean ancient, boolean emerald,
                         boolean gold, boolean iron, boolean redstone, boolean coal,
                         boolean lapis, boolean copper, boolean quartz, boolean storage) {
        public boolean keep(BlockState state) {
            if (state == null || state.isAir()) return true;
            Block block = state.getBlock();
            if (diamond && (state.is(Blocks.DIAMOND_ORE) || state.is(Blocks.DEEPSLATE_DIAMOND_ORE))) return true;
            if (ancient && state.is(Blocks.ANCIENT_DEBRIS)) return true;
            if (emerald && (state.is(Blocks.EMERALD_ORE) || state.is(Blocks.DEEPSLATE_EMERALD_ORE))) return true;
            if (gold && (state.is(Blocks.GOLD_ORE) || state.is(Blocks.DEEPSLATE_GOLD_ORE) || state.is(Blocks.NETHER_GOLD_ORE))) return true;
            if (iron && (state.is(Blocks.IRON_ORE) || state.is(Blocks.DEEPSLATE_IRON_ORE))) return true;
            if (redstone && (state.is(Blocks.REDSTONE_ORE) || state.is(Blocks.DEEPSLATE_REDSTONE_ORE))) return true;
            if (coal && (state.is(Blocks.COAL_ORE) || state.is(Blocks.DEEPSLATE_COAL_ORE))) return true;
            if (lapis && (state.is(Blocks.LAPIS_ORE) || state.is(Blocks.DEEPSLATE_LAPIS_ORE))) return true;
            if (copper && (state.is(Blocks.COPPER_ORE) || state.is(Blocks.DEEPSLATE_COPPER_ORE))) return true;
            if (quartz && state.is(Blocks.NETHER_QUARTZ_ORE)) return true;
            if (storage && (block == Blocks.CHEST || block == Blocks.TRAPPED_CHEST
                    || block == Blocks.ENDER_CHEST || block == Blocks.BARREL || block instanceof ShulkerBoxBlock)) return true;
            return false;
        }
    }
    public static volatile Filter active = new Filter(false,false,false,false,false,false,false,false,false,false,false,false);
    private static Object lastLevel;
    private static int throttle;

    /** Invoked on client thread; rebuilding only after the whitelist actually changes. */
    public static void tick(Minecraft mc, ModuleCatalog catalog) {
        // Setting changes are applied after 3 ticks to avoid repeated expensive rebuilds while editing.
        boolean enabled = mc.level != null && catalog.enabled("xray");
        Filter wanted = new Filter(enabled, BeegiOptions.diamond, BeegiOptions.ancient,
                BeegiOptions.emerald, BeegiOptions.gold, BeegiOptions.iron, BeegiOptions.redstone,
                BeegiOptions.coal, BeegiOptions.lapis, BeegiOptions.copper, BeegiOptions.quartz,
                BeegiOptions.xrayStorage);
        if (mc.level != lastLevel) { lastLevel = mc.level; active = wanted; throttle = 0; return; }
        if (!wanted.equals(active)) {
            if (++throttle >= 3) {
                active = wanted;
                throttle = 0;
                if (mc.level != null && mc.levelExtractor != null) mc.levelExtractor.allChanged();
            }
        } else throttle = 0;
    }

    /** Called on background chunk compilation workers. Never read mutable options here. */
    public static BlockState meshState(BlockState original) {
        Filter snapshot = active;
        return !snapshot.enabled() || snapshot.keep(original) ? original : Blocks.AIR.defaultBlockState();
    }
}
