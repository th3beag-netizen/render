import com.beegi.client.render.ProjectionMath;
public class ProjectionMathTest {
  public static void main(String[] args){
    var ahead = ProjectionMath.camera(0,0,4,0,0);
    if(!(ahead.depth()>3.9))throw new AssertionError("ahead depth");
    var behind = ProjectionMath.camera(0,0,-4,0,0);
    if(ProjectionMath.edge(behind,behind,800,600,70)!=null)throw new AssertionError("behind clipped");
    var clipped = ProjectionMath.edge(behind,ahead,800,600,70);
    if(clipped==null)throw new AssertionError("near-plane crossing should clip");
    if(ProjectionMath.edge(ProjectionMath.camera(-1,0,5,0,0),ProjectionMath.camera(1,0,5,0,0),800,600,70)==null)
       throw new AssertionError("visible segment");
    System.out.println("PASS: camera projection, near-plane edge clip and visible wireframe");
  }
}
